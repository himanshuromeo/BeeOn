<?php
include("conn.php");
$file = $_GET['file'];
$query1st = "SELECT * FROM notes WHERE file = '".$file."'";
$res1st = mysql_query($query1st);
while($row1st = mysql_fetch_array($res1st,MYSQL_ASSOC)){
	$downloads = "{$row1st['downloads']}";
}
$newdownloads = bcadd($downloads,1);
$query2nd = "UPDATE notes SET downloads = '".$newdownloads."' WHERE file = '".$file."'";
$res2nd = mysql_query($query2nd);
header("location:$file");
?>