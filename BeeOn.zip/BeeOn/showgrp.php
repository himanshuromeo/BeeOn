<?php
session_start();
foreach($_SESSION as $name => $stat){
	if(eregi("_",$name)){
		$tmp = explode("_",$name);
		$id = end($tmp);
	}
}
include("conn.php");
$query = "SELECT * FROM groupchat";
$re = mysql_query($query);
if(!$re){
	echo "Couldn't load chat";
}
else{
	while($row = mysql_fetch_array($re,MYSQL_ASSOC)){
		$id1 = "{$row['sender']}";
		$query2 = "SELECT * FROM reguser WHERE id = '".$id1."'";
		$re2 = mysql_query($query2);
		if(!$re2){
			echo "Couldn't load image";
		}
		else{
			while($row2 = mysql_fetch_array($re2,MYSQL_ASSOC)){
				$pic = "{$row2['profilepic']}";
			}
		}
		if($id1 != $id){
			echo "<img hspace = '15' src = '".$pic."' style = 'border-radius:50%; width: 50; height: 50;' >";
			echo "<div class = 'msg'>{$row['message']}</div><br>";
			/*echo "<div class = 'time'>{$row['time']}</div>"; */
		}
		else{
			echo "<img hspace = '15' src = '".$pic."' style = 'border-radius:50%; width: 50; height: 50;' class = 'img' >";
			echo "<div class = 'msg2'>{$row['message']}</div><br>";
			/* echo "<div class = 'time2'>{$row['time']}</div>"; */
		}
	}
}
?>