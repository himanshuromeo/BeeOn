<?php
$message=wordwrap($_POST['message'],18,"\n",true);
$message=htmlentities($message);
$id1=$_POST['sender'];
$id2 = $_POST['receiver'];
$time = date('m/d/Y h:i:s a', time());
include("conn.php");
$query = "INSERT INTO chat(id1,id2,message,time) VALUES('".$id1."','".$id2."','".mysql_escape_string($message)."','".$time."')";
$res = mysql_query($query);
if(!$res){
	echo"Couldn't send";
}
else{
	echo "sentok";
	exit();
}
?>