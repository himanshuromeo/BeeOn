<?php
include("conn.php");
$liker = $_POST['liker'];
$post_id = $_POST['post_id'];
$queryselect = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$liker."'";
$resselect = mysql_query($queryselect);
$num = mysql_num_rows($resselect);
if($num){
	echo "Already liked";
}
else{
	$queryinsert = "INSERT INTO likes (post_id,liker) VALUES('".$post_id."','".$liker."')";
	$resinsert = mysql_query($queryinsert);
}
?>