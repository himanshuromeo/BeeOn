<html>
<head>
<title>Chat</title>
<link rel = 'icon' type = 'image/jpg' href = 'logo_beeon.jpg'>
<link rel = 'stylesheet' type = 'text/css' href = 'w3.css'>
</head>
<body>
<?php 
include("m.sideview.php");
include("m.topview.php");
include("conn.php");
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$sess = end($tmp);
	}
}
$subject = $_GET['sub'];
$class = $_GET['class'];
$query = "SELECT * FROM reguser WHERE id = '".$sess."'";
$res = mysql_query($query,$conn);
while($row = mysql_fetch_array($res,MYSQL_ASSOC)){
	$img_link = "{$row['profilepic']}";
	$name = "{$row['name']}";
}
?>
<center><font color = "red" size = "6"><u><?php echo $subject; ?></u></font></center>
<img src = "<?php echo $img_link; ?>" style = "width: 110px; height:110px;" border = "2" class = "w3-circle"/>
Hey <?php echo $name; ?>, Help us OUt!!<br>
<form action="m.notesupload.php" method="post" enctype="multipart/form-data">
<textarea class="post_textbox" rows="4" wrap="hard" name="description"  placeholder="Describe ur notes"></textarea><br>                        
<input type="file" id="sbmt3" name="file1" />
<input type = "hidden" name = "user_id" value = "<?php echo $sess; ?>" /> 
<input type = "hidden" name = "subject" value = "<?php echo $subject; ?>" /> 
<input type = "hidden" name = "class" value = "<?php echo $class; ?>" /> 
<input class = "w3-btn w3-blue w3-hover-green" type="submit" value="Submit" id = "sbmt4" style=" display: inline;" />
</form><BR>
<center><font color = "red" size = "6"><u>Top Notes</u></font></center>
<?php
$query = "SELECT * FROM notes WHERE downloads >= 10 AND subject = '".$subject."' AND class = '".$class."'";
$res = mysql_query($query);
while($row = mysql_fetch_array($res,MYSQL_ASSOC)){
	$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
	$res2 = mysql_query($query2);
	while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
		echo "<div class = status><img src = '".$row2['profilepic']."' style = 'boeder-radius:50%;' width = 50 height = 50/>";
	}
	echo "uploaded notes for us on {$row['event_time']}";
	echo "<br>{$row['description']}";
	echo "<br><a href = 'open.php?file=".$row['file']."'>Download It</a>";
	echo "</div>";
}
echo "<br><b><center>No more notes to show</center></b>";
echo "<center><br><font color = red size = 6><u>Other Notes</u></font></center>";
$query = "SELECT * FROM notes WHERE downloads < 10 AND subject = '".$subject."' AND class = '".$class."'";
$res = mysql_query($query);
while($row = mysql_fetch_array($res,MYSQL_ASSOC)){
	$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
	$res2 = mysql_query($query2);
	while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
		echo "<div class = status><img src = '".$row2['profilepic']."'style = 'boeder-radius:50%;' width = 50 height = 50/>";
	}
	echo "uploaded notes for us on {$row['event_time']}";
	echo "<br>{$row['description']}";
	if($row['file'] != NULL){
		echo "<br><a href = 'open.php?file=".$row['file']."'><img src = 'download.jpg' height = '70' width = '90'></a>";
		echo "</div>";
	}
	else{
		echo "</div>";
	}
}
echo "<br><b><center>No more notes to show</center></b>";
?>
</body>
</html>