<?php
include("conn.php");
$user_id = $_POST['user_id'];
$class = $_POST['class'];
$subject = $_POST['subject'];
$description = $_POST['description'];
$event_time = date('m/d/Y h:i:s a', time());
$filename = $_FILES['file1']['name'];
$tmp = explode(".",$filename);
$exts = end($tmp);
$target_path = "Notes/".$filename;
echo "$user_id<br>".htmlentities($description)."<br>$target_path<br>$event_time";
if(!($filename == ""&& $description == "")){
	if(!(ereg("^(jpg|jpeg|bmp|png|pdf|doc|docx|txt)$",$exts))){
		if($description == ""){
			echo "File must be of jpg, bmp or png extension";
		}
		else{
			$query = "INSERT INTO notes(user_id,class,subject,file,event_time) VALUES('".$user_id."','".$class."','".$subject."','".htmlentities($description)."','".$event_time."')";
			$res = mysql_query($query,$conn);
			if(!$res){
				echo "Couldn't upload your status1";
			}
			else{
				echo "Status updated successfully";
			}
		}
	}
	else{
		move_uploaded_file($_FILES['file1']['tmp_name'], $target_path);
		$query = "INSERT INTO notes(user_id,class,subject,description,file,event_time) VALUES('".$user_id."','".$class."','".$subject."','".htmlentities($description)."','".$target_path."','".$event_time."')";
		$res = mysql_query($query,$conn);
		if(!$res){
			echo "Couldn't upload your status2";
		}
		else{
			echo "Status updated successfully";
		}
	}
}
else{
	echo "Don't leave both the fields empty";
}
?>