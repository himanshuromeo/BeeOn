<?php
include("m.sideview.php");
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id = end($tmp);
	}
}
?>
<html>
<head>
<title>My own CHAT program</title>
<link rel="stylesheet" type="text/css" href="cb_style.css">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#send").click(function() {
		var textcontent = $("#message").val();
		var id = <?php echo $id; ?>;
		var dataString = 'message='+ textcontent+'&sender=' +id;
		if(textcontent=='')
		{
			alert("Enter some text..");
			$("#message").focus();
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "sendgrp.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById('message').value='';
					document.getElementById.innerHTML = "Sent";
					$("#message").focus();
				}  
			});
		}
		return false;
	});
});
</script>
<link rel = "stylesheet" type = "text/css" href = "w3.css">
</head>

<div id="chatBox" class = "w3-card w3-khaki"><?php include("showgrp.php"); ?></div>
	<form method = "post" id="messageForm">
		<input class = "w3-input" id="message" type="text" style = 'width: 84%; border-width: 3px;border-color: blue;'/>
		<input class = "w3-btn w3-blue w3-hover-green" id="send" type="submit" value="Send" style = "margin-top: -33px; margin-left:84%;"/>
<div id="serverRes"></div></form>
<script>
$(function(){
	getchat();
});
function getchat(){
	$('#chatBox').load('showgrp.php');
	setTimeout("getchat()",2000);
}
</script>
</body>
</html>