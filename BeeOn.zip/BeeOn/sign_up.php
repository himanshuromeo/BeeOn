<html>
<head>
<title>Sign Up</title>
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<link rel="stylesheet" type = "text/css" href = "style.css">
</head>
<body background = "social-network-links.jpg">
<div id = "mid2">
<div style = "width: 30%; margin-left: 80px; margin-bottom: 20px;">
<fieldset>
<legend style = "color:brown; font-weight:bold;">Sign Up</legend>
<table width = "100%" align = "center" cellpading = "1" cellspacing = "1" style = "background-color:white;">
<form enctype = "multipart/form-data" name = "signUpForm" id = "signUpForm" action = "validate.php" method = "post">
<!---Adding a text box--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">Name:</font> </td>
<td style = "width:40%">
<input type = "text" name = "txtName" id = "txt" size = "25" maxlength = "25" tabindex = "1" value = "" /></td><br>
</tr>
<!---Adding another text box---->
<tr>
<td style = "width:40%;" align = "right"><font color="black">E-mail ID: </font></td>
<td style = "width:40%">
<input type = "text" name = "txtEmail" id = "txt" size = "25" maxlength = "30" tabindex = "4" value = "" /></td>
</tr>
<!---Adding a password field--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">Password: </font></td>
<td style = "width:40%">
<input type ="password" name = "pass" id = "txt" size = "25" tabindex = "6" value = ""/></td>
</tr>
<!---Adding school info option--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">School: </font></td>
<td style = "width:40%">
<input type ="text" name = "slctSchool" id = "txt" size = "25" tabindex = "6" value = ""/></td>
</tr>
<!---Adding class info option--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">Class: </font></td>
<td style = "width:40%">
<select id = "styled-select" name = "slctClass" size = "1" tabindex = "9">
<option>VI</option>
<option>VII</option>
<option>VIII</option>
<option>IX</option>
<option>X</option>
<option>XI</option>
<option>XII</option>
<option>Teacher</option>
</select>
</td>
</tr>
<!---Adding another text button--->
<td style = "width:40%;" align = "right"><font color="black">Admission No.: </font></td>
<td style = "width:40%">
<input type = "text" id = "txt2" name = "txtadmno" maxlength = "6" />
</td>
</tr>
<!---Adding a radio button--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">Gender: </font></td>
<td style = "width:40%">
<input type = "radio" name = "radGender" value = "Male" tabindex = "7" checked = "checked" <?php echo (isset($_POST['radGender']) && $_POST['radGender']=="male" ? 'checked="true"': '')?>/><font color="black">Male
<input type = "radio" name = "radGender" value = "Female" tabindex = "8"  <?php echo (isset($_POST['radGender']) && $_POST['radGender']=="female" ? 'checked="true"': '')?>/>Female </font></td>
</tr>
<!--Adding profile pic button--->
<tr>
<td style = "width:40%;" align = "right"><font color="black">Choose your profile picture: </font></td>
<td style = "width:40%;">
<input id = "sbmt3" type = "file" accept = "image/jpeg;capture=camera" name = "profilePic"  /></td>
</tr>
<!--Adding some Buttons--->
<tr>
<td style = "width:40%;" align = "right">
<input type = "submit" name ="btnSubmit" id = "sbmt2" value = "Submit" tabindex = "11" /></td>
<td style = "width:40%">
<input type = "reset" name = "btnReset" id = "sbmt2" value = "Cancel" tabindex = "12" /></td>
</tr>  
</form>
</table>
</fieldset>
</div>
<ul><li>
<a href = "index.php">Login</a>
</li></ul>
</div>
<div id = "end2">
<font color = "black"><center><b>Developed by</b> Himanshu & Co.</center></font>
</div>
</body>
</html>