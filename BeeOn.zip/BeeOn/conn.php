<?php
/*$conn = mysql_connect("mysql9.000webhost.com","a4976133_local","beeon123");
$db = mysql_select_db("a4976133_sns"); */
$conn = mysql_connect("localhost","root","");
$db = mysql_select_db("beeon");
?>