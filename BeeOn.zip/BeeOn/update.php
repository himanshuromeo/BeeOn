<?php
session_start();
foreach($_SESSION As $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$id = end($tmp);
	}
}
include("conn.php");
$que = "SELECT * FROM reguser WHERE id = '".$id."'";
$resue = mysql_query($que);
while($row = mysql_fetch_array($resue,MYSQL_ASSOC)){
	$emailid = "{$row['emailid']}";
	$profilepic = "{$row['profilepic']}";
}
$admnopat = "^[A-Za_z0-9]*$";
// Validation of entry begins by checking if there is any blank field left
if($_POST['txtName'] == ""){
	echo "<div id = texten><center><b>Please enter your name</b></center></div>";
	include("settings.php");
}
elseif($_POST['pass'] == ""){
	echo "<div id = texten><center><b>Please select a password</b></center></div>";
	include("settings.php");
}
elseif(!(isset($_POST['slctSchool']))){
	echo "<div id = texten><center><b>Please select your school.</b></center></div>";
	include("settings.php");
}
elseif(!(isset($_POST['slctClass']))){
	echo "<div id = texten><center><b>Please select your class.</b></center></div>";
	include("settings.php");
}
elseif($_POST['txtadmno'] == ""){
	echo "<div id = texten><center><b>Please enter your Admission No.</b></center></div>";
	include("settings.php");
}
//Pattern validation begins
elseif(!(ereg($admnopat,$_POST['txtadmno']))){
	echo "<div id = texten><center><b>Please enter your Admission No. in the format '123456' </b></center></div>";
	include("settings.php");
}
//Actual process starts
else{
	if($_FILES['profilePic']['name'] == ""){
		$query = "UPDATE reguser SET name = '".mysql_escape_string($_POST['txtName'])."' , password = '".mysql_escape_string($_POST['pass'])."' , school = '".mysql_escape_string($_POST['slctSchool'])."' , class = '".mysql_escape_string($_POST['slctClass'])."' , admno = '".mysql_escape_string($_POST['txtadmno'])."' WHERE id = '".$id."'";
		$res = mysql_query($query);
		if($res){
			echo "<div id = texten><center><b>Successfull</b></center></div>";
			include("settings.php");
		}
		else{
			echo "<div id = texten><center><b>Please try again later</b></center></div>";
			include("settings.php");
		}
	}
	else{
		$filename = $_FILES['profilePic']['name'];
		$tmp = explode(".",$filename);
		$exts = end($tmp);
		$newfilename = $emailid.".".$exts;
		$target_path = "ProfilePics/";
		$target_path = $target_path.$newfilename;
		if(!(ereg("^(jpg|jpeg|bmp|png|JPG|JPEG)$",$exts))){
			echo "<div id = texten><center><b>The file extension is not proper.It must be '.jpg' or '.jpeg' or '.bmp' or '.png'.</b></center></div>";
			include("settings.php");
		}
		else{
			unlink($profilepic);
			move_uploaded_file($_FILES['profilePic']['tmp_name'],$target_path);
			$query = "UPDATE reguser SET name = '".mysql_escape_string($_POST['txtName'])."' , password = '".mysql_escape_string($_POST['pass'])."' , school = '".mysql_escape_string($_POST['slctSchool'])."' , class = '".mysql_escape_string($_POST['slctClass'])."' , admno = '".mysql_escape_string($_POST['txtadmno'])."',profilepic = '".$target_path."' WHERE id = '".$id."'";
			$res = mysql_query($query);
			if($res){
				echo "<div id = texten><center><b>Successfully changed</b></center></div>";
				include("settings.php");
			}
			else{
				echo "<div id = texten><center><b>Please try again later</b></center></div>";
				include("settings.php");
			}
		}
	}
}

?>