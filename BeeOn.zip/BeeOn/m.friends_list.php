<html>
<head>
<title>Beeon</title>
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<script type="text/javascript">
function showUser() {
	var str = document.getElementById("message").value;
    if (str == "") {
        alert("Enter something for search");
        return;
    } 
	else{
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } 
		else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("suggestion").innerHTML = "<b><center><u><font color = 'red' size = '8'>Suggestions</font></u></center></b><br>" + xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET","m.search.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<?php
include("m.sideview.php");
include("conn.php");
foreach($_SESSION as $sess=>$stat){
	if(ereg("_",$sess)){
		$tmp = explode("_",$sess);
		$id = end($tmp);
	}
}
?>
<body>
<form name = "search" method = "get">
<input class = "w3-input" type = "text" id = "message" placeholder = "Search for a name" onChange = "showUser()"/>
<input class = "w3-btn w3-blue w3-hover-green"type = "button" value = "Search" id = "send" onClick = "showUser()"/>
</form>
<div class = "w3-smallclass w3-hover-blue"><a href = "m.request.php">
<?php
$quera = "SELECT * FROM friends WHERE receiver = '".$id."' AND accept ='0'";
$result = mysql_query($quera);
$number = mysql_num_rows($result);
echo "Requests<div class = 'w3-badge w3-red'>".$number."</div>";
?>
</a></div>
<div id = "suggestion">
<b><center><u><font color = "red" size = "8">Suggestions</font></u></center></b><br>
<?php
$request = "SELECT * FROM reguser";
$resrequest = mysql_query($request);
$numrequest = mysql_num_rows($resrequest);
for($i=0;$i<2;$i++){
	$random_id = rand(1,$numrequest);
	$stat_que = "SELECT * FROM friends WHERE (sender ='".$id."' AND receiver ='".$random_id."') OR (sender ='".$random_id."' AND receiver ='".$id."')";
	$res_statque = mysql_query($stat_que);
	$num_statque = mysql_num_rows($res_statque);
	if(!($num_statque)){
		$sqlinfo = "SELECT * FROM reguser WHERE id = '".$random_id."'";
		$ressqlinfo = mysql_query($sqlinfo);
		while($rowdash = mysql_fetch_array($ressqlinfo,MYSQL_ASSOC)){
			echo "<div class = 'w3-card-24 w3-red w3-hover-green list' style = 'margin-bottom: 6%; border-radius:6%;border-width:1%;'><center>";
			echo "<img src = '"."{$rowdash['profilepic']}'"." height = 100 width = 100 class = 'w3-circle' />";
			echo "<br><a href = 'm.profile.php?id={$rowdash['id']}'>" . $rowdash['name']."</a><br>";
			echo "Class: {$rowdash['class']}<br>";
			echo "School: {$rowdash['school']}<br>";
			echo "Adm. No.: {$rowdash['admno']}<br></center></div>";
		}
	}
}
?>
</div>
<div class = "w3-box">
<b><center><u><font color = "red" size = "8">Friends</font></u></center></b><br>
<?php
$query1 = "SELECT * FROM friends WHERE (accept = '1')AND (sender = '".$id."' OR receiver = '".$id."')";
$res1 = mysql_query($query1);
if(!$res1){
	echo "Couldn't handle query";
}
else{
	while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
		$idtest1 = "{$row1['sender']}";
		$idtest2 = "{$row1['receiver']}";
		if($idtest1 == $id){
			$idmain = $idtest2;
		}
		else{
			$idmain = $idtest1;
		}
		$query2 = "SELECT * FROM reguser WHERE id = '".$idmain."'";
		$res2 = mysql_query($query2);
		if(!$res2){
			echo "Couldn't handle query";
		}
		else{
			while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
				echo "<div class = 'w3-card-24 w3-red w3-hover-green list' style = 'margin-bottom: 6%; border-radius:6%;border-width:1%;'><center>";
				echo "<img src = '"."{$row2['profilepic']}'"." height = 100 width = 100 class = 'w3-circle' />";
				echo "<br><a href = 'm.profile.php?id={$row2['id']}'>" . $row2['name']."</a><br>";
				echo "Class: {$row2['class']}<br>";
				echo "School: {$row2['school']}<br>";
				echo "Adm. No.: {$row2['admno']}<br></center></div>";
			}
		}
	}
	echo "<b><div style = 'margin-top:7%; margin-left: 15%;'>No more friends to show</b></div>";
}
?>
</div>
</body>
</html>