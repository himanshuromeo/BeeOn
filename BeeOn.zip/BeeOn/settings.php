<html>
<head>
<title>Settings</title>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
</head>
<?php
include("conn.php");
include("sideview.php");
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id = end($tmp);
	}
}
$query = "SELECT * FROM reguser WHERE id = '".$id."'";
$res = mysql_query($query);
while($row = mysql_fetch_array($res,MYSQL_ASSOC)){
	echo "<body>";
	echo "<div id = 'mid2'>";
	echo "<div style = 'width: 30%; margin-left: 80px; margin-bottom: 20px;'>";
	echo "<fieldset>";
	echo "<legend style = 'color:brown; font-weight:bold;'>Update Profile</legend>";
	echo "<table width = '100%' align = 'center' cellpading = '1' cellspacing = '1' style = 'background-color:white;'>";
	echo "<form enctype = 'multipart/form-data' name = 'signUpForm' id = 'signUpForm' action = 'update.php' method = 'post'>";
	echo "<center>";
	echo "<img src = {$row['profilepic']} height = '80' width = '100' border = '3' class = 'user_dp'/>";
	echo "</center>";
	echo "<!---Adding a text box--->";
	echo "<tr>";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Name:</font> </td>";
	echo "<td style = 'width:40%'>";
	echo "<input type = 'text' name = 'txtName' id = 'txt' size = '25' maxlength = '15' tabindex = '1' value = '".$row['name']."' /></td><br>";
	echo "</tr>";
	echo "<!---Adding a password field--->";
	echo "<tr>";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Password: </font></td>";
	echo "<td style = 'width:40%'>";
	echo "<input type ='password' name = 'pass' id = 'txt' size = '25' tabindex = '6' value = {$row['password']} /></td>";
	echo "</tr>";
	echo "<!---Adding a school text box--->";
	echo "<tr>";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Name:</font> </td>";
	echo "<td style = 'width:40%'>";
	echo "<input type = 'text' class = 'w3-input' name = 'slctSchool' id = 'txt' size = '25' maxlength = '35' tabindex = '1' value = '".$row['school']."' /></td><br>";
	echo "</tr>";
	echo "<!---Adding class info option--->";
	echo "<tr>";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Class: </font></td>";
	echo "<td style = 'width:40%'>";
	echo "<select id = 'styled-select' name = 'slctClass' size = '1' tabindex = '9' value = {$row['class']} >";
	echo "<option>VI</option>";
	echo "<option>VII</option>";
	echo "<option>VIII</option>";
	echo "<option>IX</option>";
	echo "<option>X</option>";
	echo "<option>XI</option>";
	echo "<option>XII</option>";
	echo "<option>Teacher</option>";
	echo "</select>";
	echo "</td>";
	echo "</tr>";
	echo "<!---Adding another text button--->";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Admission No.: </font></td>";
	echo "<td style = 'width:40%'>";
	echo "<input type = 'text' id = 'txt2' name = 'txtadmno' maxlength = '6' value = {$row['admno']} />";
	echo "</td>";
	echo "</tr>";
	echo "<!---Adding profile pic button--->";
	echo "<td style = 'width:40%;' align = 'right'><font color='black'>Profile Pic: </font></td>";
	echo "<td style = 'width:40%'>";
	echo "<input type = 'file'  name = 'profilePic' />";
	echo "</td>";
	echo "</tr>";
	echo "<!--Adding some Buttons--->";
	echo "<tr>";
	echo "<td style = 'width:40%;' align = 'right'>";
	echo "<input type = 'submit' name ='btnSubmit' id = 'sbmt2' value = 'Submit' tabindex = '11' /></td>";
	echo "<td style = 'width:40%'>";
	echo "<input type = 'reset' name = 'btnReset' id = 'sbmt2' value = 'Cancel' tabindex = '12' /></td>";
	echo "</tr>";  
	echo "</form>";
	echo "</table>";
	echo "</fieldset>";
	echo "</div>";
	echo "</div>";
	echo "<div id = 'end2'>";
	echo "<font color = 'black'><center><b>Developed by</b> Himanshu & Co.</center></font>";
	echo "</div>";
	echo "</body>";
}
?>