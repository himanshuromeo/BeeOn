<?php
$sender=$_POST['sender'];
$receiver = $_POST['receiver'];
include("conn.php");
$query = "INSERT INTO friends(sender,receiver) VALUES('".$sender."','".$receiver."')";
$res = mysql_query($query);
if(!$res){
	echo"Couldn't send request";
}
else{
	echo "sentok";
	exit();
}
?>