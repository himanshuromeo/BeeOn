<?php
session_start();
if($_SESSION['beeloggedin'] == 1){
	header("location: m.main.php");
}
echo "<b><center>We could not identify you. Please try a better combination of emailid and password</center><hr color = red></b>";
include("m.index.php");
?>