<html>
<head>
<title>Beeon</title>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#accept").click(function() {
		if($("#accept").val() == "Accept"){
			var receiver = $("#hidid1").val();
			var sender = $("#hidid2").val();
			var dataString = 'receiver='+ receiver+'&sender=' +sender;
			$.ajax({
				type: "POST",
				url: "accept.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById("accept").value = "Accepted";
				}  
			});
		}
		else{
			alert("Already accepted");
		}
		return false;
	});
	$("#decline").click(function() {
		if($("#decline").val() == "Decline"){
			var receiver = $("#hidid1").val();
			var sender = $("#hidid2").val();
			var dataString = 'receiver='+ receiver+'&sender=' +sender;
			$.ajax({
				type: "POST",
				url: "decline.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById("decline").value = "Declined";
				}  
			});
		}
		else{
			alert("Already declined");
		}
		return false;
	});
});
</script>
</head>
<body>
<div id ="friends_list" style = "margin-top: 60px;">
<b><center><u><font color = "red" size = "6">'Shake Hands' Requests</font></u></center></b><br>
<?php
include("sideview.php");
foreach($_SESSION AS $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$id = end($tmp);
	}
}
include("conn.php");
$sql1 = "SELECT * FROM friends WHERE receiver = '".$id."' AND accept = '0'";
$res1 = mysql_query($sql1);
if(!$res1){
	echo "Couldn't handle query";
}
while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
	$sender = "{$row1['sender']}";
	$sql2 = "SELECT * FROM reguser WHERE id='".$sender."'";
	$res2 = mysql_query($sql2);
	while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
		echo "<img src = '"."{$row2['profilepic']}'"." height = 120 width = 100 class = 'imgfriend' />";
		echo "<div class = 'namefriend' style = 'margin-top: -130px;'><a href = 'profile.php?id={$row2['id']}'>" . $row2['name']."</a><br>";
		echo "Class: {$row2['class']}<br>";
		echo "School: {$row2['school']}<br>";
		echo "Adm. No.: {$row2['admno']}<br>";
		echo "<form method = 'post'>";
		echo "<input type = 'hidden' id = 'hidid1' value = '".$id."' />";
		echo "<input type = 'hidden' id = 'hidid2' value = '".$row2['id']."' />";
		echo "<input type = 'button' id = 'accept' value = 'Accept' />";
		echo "<input type = 'button' id = 'decline' value = 'Decline'/>";
		echo "</form></div>";
	}
}
echo "<b><center>No more 'Shake Hands' Requests</center></b>";	
?>
</div>
</body>
</html>