<?php
session_start();
if($_SESSION['beeloggedin']!=1){
	header("location:m.index.php");
}
?>
<html>
<head>
<title>Pic Store</title>
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<link rel = "icon" type = "image/jpg" href = "logo_beeon.jpg">
</head>
<body bgcolor = 'red'>
<?php
include("conn.php");
include("m.sideview.php");
$gotid = $_GET['id'];
$query = "SELECT * FROM status_update WHERE user_id = '".$gotid."'";
$res = mysql_query($query);
while($row = mysql_fetch_assoc($res)){
	if($row['image'] != NULL){
		echo "<img src = '".$row['image']."' alt = 'Sorry' style = 'width:50%;height:50%;border:2px solid black'/>";
	}
}
?>
</body>
</html>