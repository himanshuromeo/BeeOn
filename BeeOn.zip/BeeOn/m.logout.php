<?php
include("conn.php");
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id = end($tmp);
	}
}
$query = "DELETE FROM online WHERE user_id = $id";
$res = mysql_query($query);
session_destroy();
header('location:m.index.php');
?>