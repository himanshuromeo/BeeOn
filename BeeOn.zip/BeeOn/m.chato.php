<html>
<head>
<title>CHAT program</title>
<?php
function destroy(){
	session_start();
	foreach($_SESSION as $name=>$stat){
		if(ereg("@",$name)){
			unset($_SESSION["$name"]);
		}
	}
}
?>
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#send").click(function() {
		var textcontent = $("#message").val();
		var id1 = $("#hidid1").val();
		var id2 = $("#hidid2").val();
		var dataString = 'message='+ textcontent+'&sender=' +id1+'&receiver='+id2;
		if(textcontent=='')
		{
			alert("Enter some text..");
			$("#message").focus();
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "send.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById('message').value='';
					document.getElementById.innerHTML = "Sent";
					$("#message").focus();
				}  
			});
		}
		return false;
	});
});
</script>
<link rel = "stylesheet" type = "text/css" href = "w3.css">
</head>
<body onunload = "<?php destroy(); ?>">
<?php
include("conn.php");
include("m.sideview.php");
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
	}
}
if(isset($_POST['hidid1'])){
	$id1 = $_POST['hidid1'];
}
else{
	$id1 = end($tmp);
}
if(isset($_GET['id'])){
	$id2 = $_GET['id'];
}
else{
	$id2 = $_POST['hidid2'];
}
$_SESSION[$id1."@".$id2] = 1;
foreach($_SESSION As $name=>$stat){
	if(ereg("@",$name)){
		$tmp = explode("@",$name);
		$idu1 = $tmp[0];
		$idu2 = $tmp[1]; 
	}
}
$setque = "UPDATE chat SET seen = 1 WHERE id2 = '".$idu1."'";
$resque = mysql_query($setque);
$sqlinfo1 = "SELECT * FROM reguser WHERE id = '".$idu1."'";
$resinfo1 = mysql_query($sqlinfo1);
while($rowinfo1 = mysql_fetch_array($resinfo1,MYSQL_ASSOC)){
	echo "<b><center><label><a href = 'm.profile.php?id=".$rowinfo1['id']."'>{$rowinfo1['name']} </a></label>";
}
$sqlinfo2 = "SELECT * FROM reguser WHERE id = '".$idu2."'";
$resinfo2 = mysql_query($sqlinfo2);
while($rowinfo2 = mysql_fetch_array($resinfo2,MYSQL_ASSOC)){
	echo "is chatting with <label><a href = 'm.profile.php?id=".$rowinfo2['id']."'> {$rowinfo2['name']} </a></center></label></b>";
}
?>
<div class = 'w3-card w3-khaki' id="chatBox" style = 'overflow:scroll; height: 90%;border-width:2px; '><?php include("show.php"); ?></div>
	<form  method = "post" id="messageForm">
		<input id = "hidid1" style = 'display:none;'type = "text" value = "<?php echo $idu1; ?>" />
		<input id = "hidid2" style = 'display:none;'type = "text" value = "<?php echo $idu2; ?> "/>
		<input class = "w3-input" id="message" type="text" style = 'width: 84%; border-width: 3px;border-color: blue;'/>
		<input class = "w3-btn w3-blue w3-hover-green" id="send" type="submit" value="Send" style = "margin-top: -33px; margin-left:84%;"/><br>
	<div id="serverRes"></div></form>
	<form enctype = "multipart/form-data" method = "post" action = "m.chatpic.php?serve=<?php echo $idu2;?>">
		<input type = "file" id = "chatpic" name = "chatpic" />
		<input type = "submit" class = "w3-btn w3-blue w3-hover-green" value = "Send File" style = "margin-top: -33px; margin-left:80%;"/>
	</form>
<script>
$(function(){
	getchat();
});
function getchat(){
	$('#chatBox').load('show.php');
	setTimeout("getchat()",2000);
}
</script>
</body>
</html>