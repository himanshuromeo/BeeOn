<?php
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$sess = end($tmp);
	}
}
?>
<html>
<head>
<title>Beeon</title>
<meta style="color:red" name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60">
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#sendreq").click(function() {
		var sender = $("#hidido1").val();
		var receiver = $("#hidido2").val();
		var dataString = 'sender='+ sender+'&receiver=' +receiver;
		$.ajax({
			type: "POST",
			url: "sendreq.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Sent");					
			}  
		});
		return false;
	});
	$(".like").click(function() {
		var post_id = $(this).attr('id');
		var liker = <?php echo $sess; ?>;
		var dataString = 'liker='+ liker+'&post_id=' +post_id;
		$.ajax({
			type: "POST",
			url: "liker.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! This post deserves like. Your like will be visible within a minute");
			}  
		});		
		return false;
	});
	$(".put").click(function() {
		var post_id = $(this).attr('id');
		var user_id = <?php echo $sess; ?>;
		var classo = '#post_textbox2'+post_id;
		var comment = $(classo).val();
		var dataString = 'user_id='+ user_id+'&post_id=' +post_id+'&comment='+comment;
		$.ajax({
			type: "POST",
			url: "put.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! Comment on this post with open arms. Your comment will be visible within a minute");
			}  
		});		
		return false;
	});
});
</script>
</head>
<body>
<?php
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$sender = end($tmp);
	}
}
include("m.sideview.php");
include("conn.php");
$id = $_GET['id'];
$sql = "SELECT * FROM friends WHERE sender = '".$sender."' AND receiver = '".$id."' OR sender ='".$id."' AND receiver = '".$sender."'";
$res = mysql_query($sql);
if(mysql_num_rows($res)){
	$msg = "Request Sent";
}
else{
	$msg = "Shake Hands";
}
if($_SESSION['beeloggedin'] != 1){
	header("location:m.index.php");																																
}
else{
	$query = "SELECT * FROM reguser WHERE id = '".mysql_escape_string($id)."'";
	$retval = mysql_query($query);
	while($row = mysql_fetch_array($retval, MYSQL_ASSOC)){
		echo "<div class = 'w3-card-24 w3-red' style = 'text-align:center;'>";
		echo "<img style = 'border-radius:50%;' border = '2' width = '100' height = '100' alt = 'sorry' src = '"."{$row['profilepic']}"."'></img><br>";
		echo "<b>Emailid:</b> {$row['emailid']}"." <br>";
		echo "<b>Name: </b>{$row['name']}<br>";
		echo "<b>School: </b>{$row['school']}<br>";
		echo "<b>Class: </b>{$row['class']}<br>";
		echo "<b>Adm. No.: </b>{$row['admno']}<br>";
		echo "<b>Gender: </b>{$row['gender']}<br>";
		echo "<form method = 'post'>";
		echo "<input type = 'hidden' id = 'hidido1' value = '".$sender."' />";
		echo "<input type = 'hidden' id = 'hidido2' value = '".$row['id']."' />";
		if($msg == 'Shake Hands'){
			echo "<input type = 'button' id = 'sendreq' class = 'w3-btn w3-blue w3-hover-green' value = 'Shake Hands' /><br>";
			echo "<a href = m.picstore.php?id=$id><div class = 'w3-button w3-green w3-hover-blue' style = 'border-top:2px solid black;'>Pics Store</div></a>";
			echo "</form></div>";
		}
		else{
			echo "<a href = m.picstore.php?id=$id><div class = 'w3-button w3-green w3-hover-blue' style = 'border-top:2px solid black;'>Pics Store</div></a>";
			echo "</form></div>";
		}
	}
	$query = "SELECT * FROM status_update WHERE user_id = '".$id."' ORDER BY id DESC LIMIT 15";
	$res = mysql_query($query,$conn);
	if(!($res)){
		echo "Couldn't get appropriate result";
	}
	else{
		while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
			$post_id = "{$row['id']}";
			$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
			$res2 = mysql_query($query2,$conn);
			if(!($res2)){
				echo "Couldn't get appropriate result";
			}
			while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
				$user_image = "{$row2['profilepic']}";
				$gender = "{$row2['gender']}";
				if($gender == "Male"){
					$txt = "his";
				}
				else{
					$txt = "her";
				}
				echo "<div class = 'status'><img src = '".$row2['profilepic']."'class = 'w3-circle' width = 50 height = 50/>";
			}
			echo "updated $txt status on {$row['event_time']}";
			echo "<br>{$row['status_post']}";
			$image = "{$row['image']}";
			if($image == NULL){
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$sess."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
			else{
				echo "<br><img hspace = '70' src = '".$image ."' style = 'height: 50%; width: 70%;'>";
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$sess."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
		}
	}
}
?>
</body>
</html>