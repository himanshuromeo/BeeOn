<html>
<head>
<title>Chat</title>
<link rel = 'icon' type = 'image/jpg' href = 'logo_beeon.jpg'>
<link rel = 'stylesheet' type = 'text/css' href = 'w3.css'>
</head>
<body>
<?php
session_start();
foreach($_SESSION as $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$sess = end($tmp);
	}
	else{
		//will look at u
	}
}
include("conn.php");
$urquery = "SELECT * FROM reguser WHERE id = '".$sess."'";
$urres = mysql_query($urquery,$conn);
while($urrow = mysql_fetch_array($urres,MYSQL_ASSOC)){
	echo "<table border = 0><tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=maths&class={$urrow['class']}'> Mathematics </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=physics&class={$urrow['class']}'> Physics </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=chemistry&class={$urrow['class']}'> Chemistry </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=bio&class={$urrow['class']}'> Biology </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=sst&class={$urrow['class']}'> Social Studies </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=eng&class={$urrow['class']}'> English </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=hindi&class={$urrow['class']}'> Hindi </div></a></div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=sanskrit&class={$urrow['class']}'> Sanskrit </div></a><div></tr>";
	echo "<tr><div class = 'w3-card w3-blue w3-hover-green'><div class = 'link'><a href = 'm.notes.php?sub=comp&class={$urrow['class']}'> Computer </div></a></div></tr></table>";
}
?>
</div>
</body>
</html>