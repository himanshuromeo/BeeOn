<?php
include("conn.php");
$user_id = $_POST['user_id'];
$post_id = $_POST['post_id'];
$comment = $_POST['comment'];
$queryinsert = "INSERT INTO comments (user_id,post_id,post_comment) VALUES('".$user_id."','".$post_id."','".$comment."')";
$resinsert = mysql_query($queryinsert);
?>