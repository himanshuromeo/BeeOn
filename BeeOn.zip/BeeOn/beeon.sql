-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2016 at 07:59 PM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beeon`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(10) NOT NULL,
  `id1` int(10) DEFAULT NULL,
  `id2` int(10) DEFAULT NULL,
  `type` varchar(100) DEFAULT 'text',
  `file` varchar(10) DEFAULT NULL,
  `message` longtext,
  `time` varchar(100) DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `id1`, `id2`, `type`, `file`, `message`, `time`, `seen`) VALUES
(231, 1, 1, 'text', NULL, 'hlw..', '06/03/2016 06:24:24 pm', 1),
(232, 1, 1, 'file', 'beeon_logo', NULL, '06/03/2016 06:24:31 pm', 1),
(233, 1, 1, 'file', 'chat.png', NULL, '06/03/2016 06:25:04 pm', 1),
(234, 1, 1, 'file', 'beeon_logo', NULL, '06/03/2016 06:34:14 pm', 1),
(235, 1, 1, 'file', 'beeon_logo', NULL, '06/03/2016 06:37:37 pm', 1),
(236, 1, 1, 'file', 'chat.png', NULL, '06/03/2016 06:37:51 pm', 1),
(237, 1, 1, 'file', 'chat.php', NULL, '06/03/2016 06:41:54 pm', 1),
(238, 1, 1, 'text', NULL, 'hii', '06/03/2016 06:47:29 pm', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `post_id` int(10) DEFAULT NULL,
  `post_comment` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `post_comment`) VALUES
(16, 1, 36, 'thnx...'),
(17, 1, 33, 'nice...scene...'),
(18, 1, 34, 'nicy'),
(19, 2, 33, 'guuddd.....'),
(20, 1, 38, 'ok..'),
(21, 2, 39, 'nice'),
(22, 1, 43, 'hpoy\n'),
(23, 2, 41, 'http://localhost/beeon/notes.php?sub=maths'),
(24, 2, 41, 'http://localhttp://localhost/beeon/notes.php?sub=maths'),
(26, 1, 43, 'lets seee'),
(27, 1, 42, 'okkk'),
(28, 1, 37, 'ok...my turn'),
(29, 1, 36, 'hooo');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int(10) NOT NULL,
  `sender` int(10) DEFAULT NULL,
  `receiver` int(10) DEFAULT NULL,
  `accept` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`id`, `sender`, `receiver`, `accept`) VALUES
(13, 2, 3, 1),
(16, 3, 3, 1),
(17, 2, 2, 1),
(19, 1, 2, 1),
(20, 1, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groupchat`
--

CREATE TABLE `groupchat` (
  `id` int(10) NOT NULL,
  `sender` int(10) DEFAULT NULL,
  `message` varchar(5000) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groupchat`
--

INSERT INTO `groupchat` (`id`, `sender`, `message`, `time`) VALUES
(1, 1, 'hey............its jst a check, don''t respond to it....................................................did u get it????', '04/17/2016 04:46:41 pm'),
(2, 1, 'ok...', '04/17/2016 04:46:52 pm'),
(3, 2, 'ok...', '04/17/2016 04:47:49 pm'),
(4, 2, 'cooll', '04/17/2016 04:48:56 pm'),
(5, 1, 'exactly..', '04/17/2016 04:49:10 pm'),
(6, 3, 'i didn''t join u', '04/18/2016 10:32:05 am'),
(7, 2, 'http://localhost/beeon/notes.php?sub=maths', '04/19/2016 04:10:25 pm'),
(8, 1, '2', '04/27/2016 12:09:39 pm');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(10) NOT NULL,
  `post_id` int(10) DEFAULT NULL,
  `liker` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `liker`) VALUES
(90, 33, 1),
(91, 37, 1),
(92, 36, 1),
(93, 36, 2),
(94, 34, 1),
(95, 33, 2),
(96, 34, 2),
(97, 39, 2),
(98, 38, 2),
(99, 42, 1),
(100, 41, 1),
(102, 35, 1),
(103, 43, 1),
(104, 41, 2),
(105, 44, 6),
(106, 39, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `class` varchar(10) DEFAULT NULL,
  `subject` varchar(10) DEFAULT NULL,
  `description` varchar(800) DEFAULT NULL,
  `file` varchar(200) DEFAULT NULL,
  `event_time` varchar(50) DEFAULT NULL,
  `downloads` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `user_id`, `class`, `subject`, `description`, `file`, `event_time`, `downloads`) VALUES
(8, 1, 'IX', 'comp', 'Here is a list of all the shortcuts', 'Notes/Awesome_tricks.txt', '04/12/2016 06:56:04 pm', 7),
(9, 2, 'VI', 'maths', '', 'Notes/book-1.pdf', '04/17/2016 05:48:24 pm', 12),
(10, 1, 'IX', 'maths', '', 'Notes/Picture 56.jpg', '04/27/2016 10:00:17 am', 5),
(14, 1, 'IX', 'maths', 'look..', NULL, '04/27/2016 10:07:37 am', 0);

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`id`, `user_id`) VALUES
(4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reguser`
--

CREATE TABLE `reguser` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `school` varchar(20) NOT NULL,
  `class` varchar(5) NOT NULL,
  `admno` smallint(6) NOT NULL,
  `gender` text NOT NULL,
  `profilepic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reguser`
--

INSERT INTO `reguser` (`id`, `name`, `emailid`, `password`, `school`, `class`, `admno`, `gender`, `profilepic`) VALUES
(1, 'Himanshu', 'hiindia.himanshu@gmail.com', '1234', 'OPS,Ranchi', 'IX', 6253, 'Male', 'ProfilePics/hiindia.himanshu@gmail.com.jpg'),
(2, 'Riya', 'live.riyajha@gmail.com', '1234', 'OPS,Ranchi', 'VI', 905, 'Female', 'ProfilePics/live.riyajha@gmail.com.jpg'),
(3, 'Soni Jha', 'live.sonijha@gmail.com', '1234', 'OPS,Ranchi', 'VII', 1234, 'Female', 'ProfilePics/live.sonijha@gmail.com.jpg'),
(6, 'Soumya', 'suh@gmail.com', '12345', 'OPS,Ranchi', 'VI', 1234, 'Female', 'ProfilePics/suh@gmail.com.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `status_update`
--

CREATE TABLE `status_update` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `status_post` varchar(500) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `event_time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_update`
--

INSERT INTO `status_update` (`id`, `user_id`, `status_post`, `image`, `event_time`) VALUES
(33, 3, 'look at this scene', 'uploads/388866.jpg', '04/12/2016 06:54:34 pm'),
(34, 1, 'hey, check this out...', 'uploads/518129.jpg', '04/12/2016 06:55:05 pm'),
(35, 1, 'so.....I m back\r\n', NULL, '04/12/2016 06:55:18 pm'),
(36, 2, 'so...I m back as welllll', NULL, '04/12/2016 07:00:31 pm'),
(37, 1, 'its..db teat', NULL, '04/12/2016 07:24:56 pm'),
(38, 2, 'Share your feeling with others', NULL, '04/16/2016 01:07:16 pm'),
(39, 2, 'i am here for the\r\nfirst time', 'uploads/Picture 274.jpg', '04/17/2016 05:44:02 pm'),
(41, 1, '', 'uploads/DSC0176.JPG', '04/17/2016 06:57:26 pm'),
(42, 1, '', 'uploads/IMG_1431857309200.jpg', '04/17/2016 06:57:40 pm'),
(43, 1, 'hiii', 'uploads/Picture 17.jpg', '04/17/2016 07:01:17 pm'),
(44, 6, 'hiii', 'uploads/IMG_1431949706300.jpg', '04/24/2016 07:21:22 am'),
(45, 1, 'hi...', 'uploads/IMG_1431857309200.jpg', '04/29/2016 04:59:15 pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id1` (`id1`),
  ADD KEY `id2` (`id2`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender` (`sender`),
  ADD KEY `receiver` (`receiver`);

--
-- Indexes for table `groupchat`
--
ALTER TABLE `groupchat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender` (`sender`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `liker` (`liker`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `reguser`
--
ALTER TABLE `reguser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_update`
--
ALTER TABLE `status_update`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `groupchat`
--
ALTER TABLE `groupchat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `online`
--
ALTER TABLE `online`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `reguser`
--
ALTER TABLE `reguser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `status_update`
--
ALTER TABLE `status_update`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`id1`) REFERENCES `reguser` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`id2`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `reguser` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `status_update` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`sender`) REFERENCES `reguser` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`receiver`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `groupchat`
--
ALTER TABLE `groupchat`
  ADD CONSTRAINT `groupchat_ibfk_1` FOREIGN KEY (`sender`) REFERENCES `reguser` (`id`);

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `status_update` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`liker`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `online`
--
ALTER TABLE `online`
  ADD CONSTRAINT `online_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `status_update`
--
ALTER TABLE `status_update`
  ADD CONSTRAINT `status_update_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `reguser` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
