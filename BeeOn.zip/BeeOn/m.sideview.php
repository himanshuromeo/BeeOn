<html>
<head>
<meta style="color:red" name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<link rel="stylesheet" type = "text/css" href = "w3.css">
</head>
<?php
session_start();
foreach($_SESSION as $key=>$status){
		if(ereg("_",$key)){
			$tmp = explode("_",$key);
			$id = end($tmp);
			include("conn.php");
			$query = "SELECT name,emailid,school,class,admno,gender,profilepic FROM reguser WHERE id = '".$id."'";
			$retval = mysql_query($query,$conn);
			if(!($retval)){
				echo "Couldn't get appropriate result";
			}
			while($row = mysql_fetch_array($retval, MYSQL_ASSOC)){
				$img_link = "{$row['profilepic']}";
				$name = "{$row['name']}";
				$class = "{$row['class']}";
			}
			$seenque = "SELECT * FROM chat WHERE id2 = '".$id."' AND seen = 0";
			$resque = mysql_query($seenque);
			$notseen = mysql_num_rows($resque);
		}
	}
?>
<body>
<nav class="w3-sidenav w3-black w3-card-8 w3-border nav" style="display:none">
    <img src = "logo_beeon.jpg" height = "50" width = "100" hspace = "35" style = "border-radius: 50%; margin-top:5%; margin-left:30%;margin-bottom: 2px;" /><br>
	<a href="javascript:void(0)" onclick="w3_close()" class="w3-closenav w3-large">Close &times;</a>
  	<!--1--->
	<a href = "m.main.php">
	<table border = 0>
	<tr>
	<td><img src = "home.png" height = "50" width = "50" hspace = "8" /></td>
	<td><font color = "white" size = "4">Home</td>
	</tr>
	</table>
	</a>
	<!---2--->
	<a href = "m.aboutu.php">
	<table border = 0>
	<tr>
	<td><img src = "<?php echo $img_link; ?>" height = "50" width = "50" hspace = "8" class = "w3-circle"/></td>
	<td><font color = "white" size = "4"><?php echo $name; ?></td>
	</tr>
	</table>
	</a>
	<!---3--->
	<a href = "m.friends_list.php">
	<table border = 0>
	<tr>
	<td><img src = "friends-icon.png" height = "50" width = "50" hspace = "8" /></td>
	<td><font color = "white" size = "4">Friends</td>
	</tr>
	</table>
	</a>
	<!---4--->
	<a href = "m.chat.php">
	<table border = 0>
	<tr>
	<td><img src = "chat.png" height = "50" width = "50" hspace = "8" /></td>
	<td><font color = "white" size = "4">Chat <div class = "w3-badge w3-red"><?php echo $notseen; ?></div></td>
	</tr>
	</table>
	</a>
	<!---5--->
	<a href = "m.chat_common.php">
	<table border = 0>
	<tr>
	<td><img src = "received.png" height = "50" width = "50" hspace = "8" /></td>
	<td><font color = "white" size = "4">Common Chat</td>
	</tr>
	</table>
	</a>
	<!---6--->
	<a href = "m.notes.php?sub=maths&class=<?php echo $class; ?>">
	<table border = 0>
	<tr>
	<td><img src = "notes.png" height = "50" width = "50" hspace = "8" /></td>
	<td><font color = "white" size = "4">Share Notes</td>
	</tr>
	</table>
	</a>
	<!---6--->
	<a href = "m.settings.php">
	<table border = 0>
	<tr>
	<td><img src = "settings.png" height = "50" width = "50" hspace = "8" style = "border-radius: 50%;"/></td>
	<td><font color = "white" size = "4">Settings</td>
	</tr>
	</table>
	</a>
	
	<!---7--->
	<a href = "m.logout.php">
	<table border = 0>
	<tr>
	<td><img src = "logout.png" height = "50" width = "50" hspace = "8" style = "border-radius: 50%;"/></td>
	<td><font color = "white" size = "4">Log Out</td>
	</tr>
	</table>
	</a>
</nav>
<nav class="w3-sidenav w3-black w3-card-8 w3-border online" style="display:none">
	<a href="javascript:void(0)" onclick="w3_close2()" class="w3-closenav w3-large">Close &times;</a>
	<?php
	$query1 = "SELECT * FROM online";
	$res1 = mysql_query($query1);
	while($row1=mysql_fetch_array($res1,MYSQL_ASSOC)){
		$query2 = "SELECT * FROM friends WHERE (sender = '".$id."' AND receiver = '".$row1['user_id']."' AND accept = '1') OR (sender = '".$row1['user_id']."' AND receiver = '".$id."' AND accept = '1')";
		$res2 = mysql_query($query2);
		$bool2 = mysql_num_rows($res2);
		if($bool2){
			$query3 = "SELECT * FROM reguser WHERE id = '".$row1['user_id']."'";
			$res3 = mysql_query($query3);
			while($row3 = mysql_fetch_array($res3,MYSQL_ASSOC)){
				echo "<a href = m.chato.php?id={$row1['user_id']} ";
				echo "<table border = 0>";
				echo "<tr>";
				echo "<td><img src = {$row3['profilepic']} height = 50 width = 50 hspace = 8 class = 'w3-circle'/></td>";
				echo "<td><font color = white size = 4>{$row3['name']}</font></td>";
				echo "</tr>";
				echo "</table>";
				echo "</a>";
			}
		}
		else{
			//let's see
		}
	}
	?>
</nav>
<header class="w3-container w3-teal">
<span class="w3-opennav w3-xlarge" onclick="w3_open()" ><img src = 'side.png' /></span>   
<font size = "3"><b> Welcome to Beeon <?php echo $name; ?></b></font>
<span class="w3-opennav w3-xlarge check" style = "margin-right:0;float:right;"onclick="w3_open2()"><img src = 'on.png' /></span> 
</header>
<script>
function w3_open() {
    document.getElementsByClassName("nav")[0].style.display = "block";
}
function w3_close() {
    document.getElementsByClassName("nav")[0].style.display = "none";
}
function w3_open2() {
    document.getElementsByClassName("online")[0].style.display = "block";
}
function w3_close2() {
    document.getElementsByClassName("online")[0].style.display = "none";
}
</script>
</body>
</html>