<?php
$txt = "No comments to show";
echo "<font color = 'red' size = '5'>Comments</font>";
$que = "SELECT * FROM comments WHERE post_id = '".$post_id."'";
$resque = mysql_query($que);
while($rowque = mysql_fetch_array($resque,MYSQL_ASSOC)){
	$que2 = "SELECT * FROM reguser WHERE id = '".$rowque['user_id']."'";
	$resque2 = mysql_query($que2);
	while($rowque2 = mysql_fetch_array($resque2,MYSQL_ASSOC)){
		$profilepic = "{$rowque2['profilepic']}";
	}
	echo "<div class = 'comment'>";
	echo "<img src = '".$profilepic."' height = '40' width = '40' class = 'user_dp' />";
	echo "<div class = 'textcomm'>".$rowque['post_comment']."</div><br>";
	echo "</div>";
	$txt = "No more comments to show";
}
echo "<br><b><font color = 'black' size = '3'>$txt</b></font>";
echo "<br><font color = 'red' size = '4'>Your Turn</font><br>";
echo "<textarea id='post_textbox2".$post_id."' class = 'post_textbox2' rows='4' wrap='hard' name='status' maxlength = '100' placeholder='Comment in just 100 letters and within a minute'></textarea>";
echo "<input type = 'button' class = 'put' id = '".$post_id."' value = 'Put'/>";
?>