<?php
$message=strip_tags($_POST['message']);
$message=stripslashes($message);
$id1=$_POST['sender'];
$time = date('m/d/Y h:i:s a', time());
include("conn.php");
$query = "INSERT INTO groupchat(sender,message,time) VALUES('".$id1."','".mysql_escape_string($message)."','".$time."')";
$res = mysql_query($query);
if(!$res){
	echo"Couldn't send";
}
else{
	echo "sentok";
	exit();
}
?>