<?php
session_start();
foreach($_SESSION as $name => $stat){
	if(eregi("@",$name)){
		$use = $name;
		$tmp = explode("@",$use);
		$id1 = $tmp[0];
		$id2 = $tmp[1];
	}
}
include("conn.php");
$query = "SELECT id,id1,id2,type,message,file,time FROM chat WHERE id1 = '".$id1."' AND id2 ='".$id2."' OR id1 ='".$id2."' AND id2 ='".$id1."' ORDER BY id ASC";
$re = mysql_query($query);
if(!$re){
	echo "Couldn't load chat";
}
else{
	while($row = mysql_fetch_array($re,MYSQL_ASSOC)){
		$msg = "{$row['message']}";
		$msg = str_replace("|happy|","<img src = 'emozy/happy.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|angry|","<img src = 'emozy/angry.jpg' height = '40' style = 'border-radius:50%;'>",$msg);
		$msg = str_replace("|awesome|","<img src = 'emozy/awesome.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|birthday|","<img src = 'emozy/birthday.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|brave|","<img src = 'emozy/brave.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|broken heart|","<img src = 'emozy/broken heart.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|clicking|","<img src = 'emozy/clicking.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|cool|","<img src = 'emozy/cool.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|no|","<img src = 'emozy/no.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|crying|","<img src = 'emozy/crying.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|delicious|","<img src = 'emozy/delicious.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|dreaming|","<img src = 'emozy/dreaming.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|drunk|","<img src = 'emozy/drunk.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|eating|","<img src = 'emozy/eating.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|flipping|","<img src = 'emozy/flipping.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|fought|","<img src = 'emozy/fought.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|gift|","<img src = 'emozy/gift.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|gud mrng|","<img src = 'emozy/gud mrng.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|gud ni8 board|","<img src = 'emozy/gud ni8 board.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|gud ni8|","<img src = 'emozy/gud ni8.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|handsome|","<img src = 'emozy/handsome.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|hello|","<img src = 'emozy/hello.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|hello grp|","<img src = 'emozy/hello grp.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|hi|","<img src = 'emozy/hi.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|hi2|","<img src = 'emozy/hi2.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|hv grt day|","<img src = 'emozy/hv grt day.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|in luv|","<img src = 'emozy/in luv.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|juicy|","<img src = 'emozy/juicy.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|listening|","<img src = 'emozy/listening.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|lovely|","<img src = 'emozy/lovely.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|luv u|","<img src = 'emozy/lov u.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|nature|","<img src = 'emozy/nature.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|nice|","<img src = 'emozy/nice.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|nic wrk|","<img src = 'emozy/nic wrk.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|ok|","<img src = 'emozy/ok.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|partner|","<img src = 'emozy/partner.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|red yellow|","<img src = 'emozy/red yellow.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|respect me|","<img src = 'emozy/respect me.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|rubbish|","<img src = 'emozy/rubbish.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|shutup|","<img src = 'emozy/shutup.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|snacks|","<img src = 'emozy/snacks.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|think|","<img src = 'emozy/think.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|sick|","<img src = 'emozy/sink.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|watching|","<img src = 'emozy/watching.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|what|","<img src = 'emozy/what.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|will u|","<img src = 'emozy/will u.jpg' height = '40' style = 'border-radius:50%'>",$msg);
		$msg = str_replace("|india|","<img src = 'emozy/india.png' height = '40' >",$msg);
		$msg = str_replace("|pakistan|","<img src = 'emozy/pakistan.png' height = '40' >",$msg);
		$msg = str_replace("|japan|","<img src = 'emozy/japan.png' height = '40' >",$msg);
		$msg = str_replace("|srilanka|","<img src = 'emozy/srilanka.png' height = '40' >",$msg);
		$msg = str_replace("|america|","<img src = 'emozy/america.png' height = '40' >",$msg);
		$msg = str_replace("|bangladesh|","<img src = 'emozy/bangladesh.png' height = '40' >",$msg);
		$msg = str_replace("|uk|","<img src = 'emozy/uk.png' height = '40' >",$msg);
		$id1 = "{$row['id1']}";
		$query2 = "SELECT * FROM reguser WHERE id = '".$id1."'";
		$re2 = mysql_query($query2);
		if(!$re2){
			echo "Couldn't load image";
		}
		else{
			while($row2 = mysql_fetch_array($re2,MYSQL_ASSOC)){
				$pic = "{$row2['profilepic']}";
			}
		}
		if($id1 != $use[0]){
			echo "<img hspace = '15' src = '".$pic."' style = 'border-radius:50%; width: 50; height: 50;' >";
			if($row['type']=='text'){
				echo "<div class = 'msg'>$msg</div><br>";
				/* echo "<div class = 'time2'>{$row['time']}</div>"; */
			}
			else{
				echo "<div class = 'msg' style = 'width:40%;background-color:grey;'><center>Download <a href = chatfiles/{$row['file']}>{$row['file']}</a></center></div><br>";
			}
		}
		else{
			echo "<img hspace = '15' src = '".$pic."' style = 'border-radius:50%; width: 50; height: 50;' class = 'img' >";
			if($row['type']=='text'){
				echo "<div class = 'msg2'>$msg</div><br>";
				/* echo "<div class = 'time2'>{$row['time']}</div>"; */
			}
			else{
				echo "<div class = 'msg2' style = 'width:40%;background-color:grey;'><center>Download <a href = chatfiles/{$row['file']}>{$row['file']}</a></center></div><br>";
			}
		}
	}
}
?>