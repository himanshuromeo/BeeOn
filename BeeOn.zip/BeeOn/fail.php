<?php
session_start();
if($_SESSION['beeloggedin'] == 1){
	header("location: main.php");
}
echo "<div id = texten><center>We could not identify you. Please try a better combination of emailid and password</center><hr color = red></div>";
include("index.php");
?>