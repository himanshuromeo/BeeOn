<?php
session_start();
if($_SESSION['beeloggedin'] == 1){
	header("location:m.main.php");
}
//This is gonna be processed since you set the login value to on
elseif($_GET['login']){
	if(!($_POST['txtid'] == ""||$_POST['txtpass'] == "")){
		$emailid = $_POST['txtid'];
		include("conn.php");
		$query = "SELECT id,emailid,password FROM reguser WHERE emailid = '".htmlentities($_POST['txtid'])."'AND password = '".htmlentities($_POST['txtpass'])."' ";
		$resultlogin = mysql_query($query);
		while($row = mysql_fetch_array($resultlogin, MYSQL_ASSOC)){
			$id = "{$row['id']}";
		}
		$num = mysql_num_rows($resultlogin);
		if($num){
			$_SESSION['beeloggedin'] = 1;
			$idf = "_"."$id";
			$_SESSION["$idf"] = 1; //A session by your name, now you will explore the world of h!m@nshU
			$oncheck = "SELECT * FROM online WHERE user_id='".$id."'";
			$resoncheck = mysql_query($oncheck);
			$numoncheck = mysql_num_rows($resoncheck);
			if($numoncheck){
				header("location:m.main.php"); 
			}
			else{
				$online = "INSERT INTO online(user_id) VALUES('".$id."')";
				$resonline = mysql_query($online);
				header("location:m.main.php");
			}
		}
		//Why did you get it wrong ??
		else{
			header("location:m.fail.php");
		}
	}
	else echo "<div id = texten><center><b>You did not enter something or the other.</b></center><hr color = red></div>";
}
?>
<html>
<head>
<title>Beeon</title>
<meta style="color:red" name="viewport" content="width=device-width, initial-scale=1">
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
</head>
<body bgcolor = "skyblue">
<div class = "w3-box">
<img src = "logo_beeon.jpg" height = "60" class = "w3-circle"/>
<form method = "post" action = "?login=1" ><b><font size = "5%"><label class = "w3-label w3-blue">Log In:</label></font></b><br>
Email Id:<input name = "txtid" type = "text" class = "w3-input " value = "" />
Password: <input name = "txtpass" type = "password" class = "w3-input " value = ""  />
<input type = "submit" class = "w3-btn w3-blue w3-hover-green" value = "Login" />
</form>
<br>
<div class = "w3-hover-blue w3-smallclass"><a href = "m.sign_up.php">Sign Up</a></div>
</div>
<div id = "end">
<font color = "black"><center><b>Developed by</b> Himanshu & Co.</center></font>
</div>
</body>
</html>