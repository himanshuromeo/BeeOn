<html>
<head>
<link rel="stylesheet" type="text/css" href="cb_style.css">
</head>
<body>
<?php
session_start();
foreach($_SESSION as $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$sender = end($tmp);
	}
}
$q = $_GET['q'];
include("conn.php");
if (!$conn) {
    die('Could not connect: ' . mysql_error($conn));
}
$query = "SELECT * FROM reguser WHERE id = '".$q. "' OR name = '" .$q. "' OR class = '".$q."' OR admno = '".$q."' OR school = '".$q."' OR emailid = '".$q."'";
$result = mysql_query($query);
if(!($result)){
	echo "Can't suggest you friends at the moment";
}
else{
	while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
		echo "<img src = '" . $row['profilepic'] . "' class = 'imgfriend' height = 100 width = 100 />";
		echo "<div class = 'namefriend'><a href = 'profile.php?id={$row['id']}'>" . $row['name']."</a><br>";
		echo "Class: {$row['class']}<br>";
		echo "School: {$row['school']}<br>";
		echo "Adm. No.: {$row['admno']}<br></div>";
	}
}
?>
</body>
</html>