<?php
include('conn.php');
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id1 = end($tmp);
	}
}
$event_time = date('m/d/Y h:i:s a', time());
$id2 = $_GET['serve'];
$file = $_FILES['chatpic']['name'];
if($file==''){
	echo "You didn't select a file to send. Click on the File/Browse button and then click Send File. You will be redirected to the previous page in 3 secs";
	header("location:m.chato.php?id=$id2");
}
$targetpath = "chatfiles/$file";
if(move_uploaded_file($_FILES['chatpic']['tmp_name'],$targetpath)){
	$query = "INSERT INTO chat(id1,id2,type,file,time,seen) VALUES('".$id1."','".$id2."','file','".$file."','".$event_time."','0')";
	$res = mysql_query($query);
	header("location:m.chato.php?id=$id2");
}
else{
	header("location:m.chato.php?id=$id2");
}
?>