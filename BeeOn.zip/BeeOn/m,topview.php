<html>
<head>
<title>Chat</title>
<link rel = 'icon' type = 'image/jpg' href = 'logo_beeon.jpg'>
<link rel = 'stylesheet' type = 'text/css' href = 'w3.css'>
</head>
<body>
<?php
session_start();
foreach($_SESSION as $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$sess = end($tmp);
	}
	else{
		//will look at u
	}
}
include("conn.php");
$urquery = "SELECT * FROM reguser WHERE id = '".$sess."'";
$urres = mysql_query($urquery,$conn);
while($urrow = mysql_fetch_array($urres,MYSQL_ASSOC)){
	echo "<table border = 0><tr><a href = 'notes.php?sub=maths&class={$urrow['class']}'> Mathematics </a></tr>";
	echo "<tr><a href = 'notes.php?sub=physics&class={$urrow['class']}'> Physics </a></tr>";
	echo "<tr><a href = 'notes.php?sub=chemistry&class={$urrow['class']}'> Chemistry </a></tr>";
	echo "<tr><a href = 'notes.php?sub=bio&class={$urrow['class']}'> Biology </a></tr>";
	echo "<tr><a href = 'notes.php?sub=sst&class={$urrow['class']}'> Social Studies </a></tr>";
	echo "<tr><a href = 'notes.php?sub=eng&class={$urrow['class']}'> English </a></tr>";
	echo "<tr><a href = 'notes.php?sub=hindi&class={$urrow['class']}'> Hindi </a></tr>";
	echo "<tr><a href = 'notes.php?sub=sanskrit&class={$urrow['class']}'> Sanskrit </a></tr>";
	echo "<tr><a href = 'notes.php?sub=comp&class={$urrow['class']}'> Computer </a></tr></table>";
}
?>
</div>
</body>
</html>