<?php
session_start();
if($_SESSION['beeloggedin'] != 1){
	header("location:index.php");
}
else{
	foreach($_SESSION as $key=>$status){
		if(ereg("_",$key)){
			$tmp = explode("_",$key);
			$id = end($tmp);
			include("conn.php");
			$query = "SELECT name,emailid,school,class,admno,gender,profilepic FROM reguser WHERE id = '".$id."'";
			$retval = mysql_query($query,$conn);
			if(!($retval)){
				echo "Couldn't get appropriate result";
			}
			while($row = mysql_fetch_array($retval, MYSQL_ASSOC)){
				$img_link = "{$row['profilepic']}";
				$name = "{$row['name']}";
				$class = "{$row['class']}";
			}
		}
	}
}
?>
<html>
<head>
<meta http-equiv="refresh" content="180">
<title>Beeon</title>
<meta style="color:red" name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<link rel="stylesheet" type = "text/css" href = "w3.css">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$(".like").click(function() {
		var post_id = $(this).attr('id');
		var liker = <?php echo $id; ?>;
		var dataString = 'liker='+ liker+'&post_id=' +post_id;
		$.ajax({
			type: "POST",
			url: "liker.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! This post deserves like. Your like will be visible within a minute");
			}  
		});		
		return false;
	});
	$('.liked').click(function(){
		alert("Hey, this is wrong. We r here for liking each other. We've not got the right to dislike others.");
	})
	$(".w3-hover-red").click(function() {
		var post_id = $(this).attr('id');
		var user_id = <?php echo $id; ?>;
		var classo = '#post_textbox2'+post_id;
		var comment = $(classo).val();
		var dataString = 'user_id='+ user_id+'&post_id=' +post_id+'&comment='+comment;
		$.ajax({
			type: "POST",
			url: "put.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! Comment on this post with open arms. Your comment will be visible within a minute");
			}  
		});		
		return false;
	});
});
</script>
</head>
<body>
<?php include("m.sideview.php"); ?>
<img src = "<?php echo $img_link; ?>" style = "margin-left:2%;; width: 25%; height:25%;" border = "2" class = "w3-circle"/>
Hey <?php echo $name; ?>, What're u doing..?<br>
<form action="m.upload.php" method="post" enctype="multipart/form-data">
<textarea class="post_textbox" rows="4" wrap="hard" name="status"  placeholder="Share your feeling with others"></textarea><br>                        
<input type="file" id="sbmt3" name="file1" style="margin-left:2%;"/>
<input type = "hidden" name = "user_id" value = "<?php echo $id; ?>" /> 
<input type="submit" value="Submit" class = "w3-btn w3-blue w3-hover-green" style=" display: inline;" />
</form>
<?php
$query = "SELECT * FROM status_update WHERE user_id = '".$id."' ORDER BY id DESC LIMIT 5";
$res = mysql_query($query,$conn);
if(!($res)){
	echo "Couldn't get appropriate result";
}
else{
	while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
		$post_id = "{$row['id']}";
		$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
		$res2 = mysql_query($query2,$conn);
		if(!($res2)){
			echo "Couldn't get appropriate result";
		}
		while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
			$user_image = "{$row2['profilepic']}";
			$gender = "{$row2['gender']}";
			if($gender == "Male"){
				$txt = "his";
			}
			else{
				$txt = "her";
			}
			echo "<div class = 'status'><img src = '".$row2['profilepic']."'class = 'w3-circle' width = 50 height = 50/>";
		}
		echo "updated $txt status on {$row['event_time']}";
		echo "<br>{$row['status_post']}";
		$image = "{$row['image']}";
		if($image == NULL){
			echo "<div class = 'showlikes'>";
			$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
			$reslike = mysql_query($querylike);
			$numlikes = mysql_num_rows($reslike);
			$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
			$boolres = mysql_query($boolquery);
			$boolno = mysql_num_rows($boolres);
			if($boolno){
				echo "<br><img src = 'images.png' class = 'liked' />";
				echo "<font color = blue>".$numlikes." user liked this</font>";
				echo "</div>";
				include("m.comment.php");
				echo "</div>";
			}
			else{
				echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
				echo "<font color = blue>".$numlikes." user liked this</font>";
				echo "</div>";
				include("m.comment.php");
				echo "</div>";
			}
		}
		else{
			echo "<br><img hspace = '70' src = '".$image ."' style = 'height: 50%; width: 70%;'>";
			echo "<div class = 'showlikes'>";
			$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
			$reslike = mysql_query($querylike);
			$numlikes = mysql_num_rows($reslike);
			$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
			$boolres = mysql_query($boolquery);
			$boolno = mysql_num_rows($boolres);
			if($boolno){
				echo "<br><img src = 'images.png' class = 'liked' />";
				echo "<font color = blue>".$numlikes." user liked this</font>";
				echo "</div>";
				include("m.comment.php");
				echo "</div>";
			}
			else{
				echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
				echo "<font color = blue>".$numlikes." user liked this</font>";
				echo "</div>";
				include("m.comment.php");
				echo "</div>";
			}
		}
	}
}
$query1 = "SELECT  * FROM friends WHERE (sender = '".$id."' OR receiver = '".$id."') AND (accept = '1')";
$res1 = mysql_query($query1);
if(!$res1){
	echo "Couldn't get your friends list";
}
else{
	while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
		$query = "SELECT * FROM status_update WHERE (user_id != '".$id."' )AND (user_id ='".$row1['sender']."' OR user_id = '".$row1['receiver']."') ORDER BY id DESC LIMIT 4";
		$res = mysql_query($query,$conn);
		if(!($res)){
			echo "Couldn't get appropriate result";
		}
		while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
			$post_id = "{$row['id']}";
			$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
			$res2 = mysql_query($query2,$conn);
			if(!($res2)){
				echo "Couldn't get appropriate result";
			}
			while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
				$user_image = "{$row2['profilepic']}";
				$gender = "{$row2['gender']}";
				if($gender == "Male"){
					$txt = "his";
				}
				else{
					$txt = "her";
				}
				echo "<div class = 'status'><img src = '".$row2['profilepic']."'class = 'w3-circle' width = 50 height = 50/>";
			}
			echo "updated $txt status on {$row['event_time']}";
			echo "<br>{$row['status_post']}";
			$image = "{$row['image']}";
			if($image == NULL){
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
			else{
				echo "<br><img hspace = '70' src = '".$image ."' style = 'height: 50%; width: 70%;'>";
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
		}
	}
	while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
		$query = "SELECT * FROM status_update WHERE (user_id != '".$id."' )AND (user_id ='".$row1['sender']."' OR user_id = '".$row1['receiver']."') ORDER BY id DESC LIMIT -2";
		$res = mysql_query($query,$conn);
		if(!($res)){
			echo "Couldn't get appropriate result";
		}
		while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
			$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
			$res2 = mysql_query($query2,$conn);
			if(!($res2)){
				echo "Couldn't get appropriate result";
			}
			while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
				$user_image = "{$row2['profilepic']}";
				$gender = "{$row2['gender']}";
				if($gender == "Male"){
					$txt = "his";
				}
				else{
					$txt = "her";
				}
				echo "<div class = 'status'><img src = '".$row2['profilepic']."'class = 'w3-circle' width = 50 height = 50/>";
			}
			echo "updated $txt status on {$row['event_time']}";
			echo "<br>{$row['status_post']}";
			$image = "{$row['image']}";
			if($image == NULL){
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
			else{
				echo "<br><img hspace = '70' src = '".$image ."'style = 'height: 50%; width: 70%;'>";
				echo "<div class = 'showlikes'>";
				$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
				$reslike = mysql_query($querylike);
				$numlikes = mysql_num_rows($reslike);
				$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
				$boolres = mysql_query($boolquery);
				$boolno = mysql_num_rows($boolres);
				if($boolno){
					echo "<br><img src = 'images.png' class = 'liked' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
				else{
					echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
					echo "<font color = blue>".$numlikes." user liked this</font>";
					echo "</div>";
					include("m.comment.php");
					echo "</div>";
				}
			}
		}
	}
}
?>
<center><font color = "red"> Developed by <b>Himanshu & Co.</font></b></center>
</body>
</html>