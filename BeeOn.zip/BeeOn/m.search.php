<html>
<head>
<link rel="stylesheet" type="text/css" href="cb_style.css">
</head>
<body>
<?php
session_start();
foreach($_SESSION as $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$sender = end($tmp);
	}
}
$q = $_GET['q'];
include("conn.php");
if (!$conn) {
    die('Could not connect: ' . mysql_error($conn));
}
$query = "SELECT * FROM reguser WHERE id = '".$q. "' OR name = '" .$q. "' OR class = '".$q."' OR admno = '".$q."' OR school = '".$q."' OR emailid = '".$q."'";
$result = mysql_query($query);
if(!($result)){
	echo "Can't suggest you friends at the moment";
}
else{
	while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
		echo "<div class = 'w3-card-24 w3-blue w3-hover-green list' style = 'margin-bottom: 6%; border-radius:6%;border-width:1%;'><center>";
		echo "<img src = '"."{$row['profilepic']}'"." height = 100 width = 100 class = 'w3-circle' />";
		echo "<br><a href = 'm.profile.php?id={$row['id']}'>" . $row['name']."</a><br>";
		echo "Class: {$row['class']}<br>";
		echo "School: {$row['school']}<br>";
		echo "Adm. No.: {$row['admno']}<br></cewnter></div>";
	}
}
?>
</body>
</html>