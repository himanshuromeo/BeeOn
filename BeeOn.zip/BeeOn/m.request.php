<?php
session_start();
foreach($_SESSION AS $name=>$stat){
	if(ereg("_",$name)){
		$tmp = explode("_",$name);
		$id = end($tmp);
	}
}
include("conn.php");
include("m.sideview.php");
?>
<html>
<head>
<title>Requests</title>
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script>
$(function() {
	$(".accept").click(function() {
		var reqid = $(this).attr('id');
		var reqido = "#"+reqid;
		if($(reqido).val() == "Accept"){
			var real = reqid.slice(2);
			var sender = real;
			var receiver = <?php echo $id; ?>;
			var dataString = 'receiver='+ receiver+'&sender=' +sender;
			$.ajax({
				type: "POST",
				url: "accept.php",
				data: dataString,
				cache: true,
				success: function(html){
					alert("Accepted! Now hang on with ur friend for long");
				}  
			});
		}
		else{
			alert("Already accepted");
		}
		return false;
	});
	$(".decline").click(function(){
		var reqid = $(this).attr('id');
		var reqido = "#"+reqid;
		if($(reqido).val() == "Decline"){
			var real = reqid.slice(2);
			var sender = real;
			var receiver = <?php echo $id; ?>;
			var dataString = 'receiver='+ receiver+'&sender=' +sender;
			$.ajax({
				type: "POST",
				url: "decline.php",
				data: dataString,
				cache: true,
				success: function(html){
					alert("Declined! We don't appreciate this. But will take that");
				}  
			});
		}
		else{
			alert("Already declined");
		}
		return false;
	});
});
</script>
</head>
<body>
<div class = "w3-box" id ="friends_list" style = "margin-top: 5%;">
<b><center><u><font color = "red" size = "6">'Shake Hands' Requests</font></u></center></b><br>
<?php
$sql1 = "SELECT * FROM friends WHERE receiver = '".$id."' AND accept = '0'";
$res1 = mysql_query($sql1);
if(!$res1){
	echo "Couldn't handle query";
}
while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
	$sender = "{$row1['sender']}";
	$sql2 = "SELECT * FROM reguser WHERE id='".$sender."'";
	$res2 = mysql_query($sql2);
	while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
		echo "<div class = 'w3-card-24 w3-red w3-hover-pink list' style = 'margin-bottom: 6%; border-radius:6%;border-width:1%;'><center>";
		echo "<img src = '"."{$row2['profilepic']}'"." height = 100 width = 100 class = 'w3-circle' />";
		echo "<br><a href = 'm.profile.php?id={$row2['id']}'>" . $row2['name']."</a><br>";
		echo "Class: {$row2['class']}<br>";
		echo "School: {$row2['school']}<br>";
		echo "Adm. No.: {$row2['admno']}<br>";
		echo "<form method = 'post'>";
		echo "<input type = 'button' class = 'w3-btn w3-blue w3-hover-green accept' style = 'border:2px; margin-right: 1%;'id = 'ac".$row2['id']."' value = 'Accept' />";
		echo "<input type = 'button' class = 'w3-btn w3-blue w3-hover-green decline' style = 'border:2px;' id = 'de".$row2['id']."' value = 'Decline'/>";
		echo "</form></center></div>";
	}
}
echo "<b><center>No more 'Shake Hands' Requests</center></b>";	
?>
</div>
</body>
</html>