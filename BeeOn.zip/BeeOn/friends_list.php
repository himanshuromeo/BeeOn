<html>
<head>
<title>Beeon</title>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
<script type="text/javascript">
function showUser() {
	var str = document.getElementById("message").value;
    if (str == "") {
        alert("Enter something for search");
        return;
    } 
	else{
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } 
		else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("suggestion").innerHTML = "<b><center><u><font color = 'red' size = '8'>Suggestions</font></u></center></b><br>" + xmlhttp.responseText;
            }
        };
        xmlhttp.open("GET","search.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<?php
include("sideview.php");
include("conn.php");
foreach($_SESSION as $sess=>$stat){
	if(ereg("_",$sess)){
		$tmp = explode("_",$sess);
		$id = end($tmp);
	}
}
?>
<body>
<form name = "search" method = "get">
<input type = "text" id = "message" placeholder = "Search for a name" onChange = "showUser()"/>
<input type = "button" value = "Search" id = "send" onClick = "showUser()"/>
</form>
<div id = "Request"><a href = "request.php">
<?php
$quera = "SELECT * FROM friends WHERE receiver = '".$id."' AND accept ='0'";
$result = mysql_query($quera);
$number = mysql_num_rows($result);
echo "Requests(".$number.")";
?>
</a></div>
<div id = "friends_list">
<b><center><u><font color = "red" size = "8">Friends</font></u></center></b><br>
<?php
$query1 = "SELECT * FROM friends WHERE (accept = '1')AND (sender = '".$id."' OR receiver = '".$id."')";
$res1 = mysql_query($query1);
if(!$res1){
	echo "Couldn't handle query";
}
else{
	while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
		$idtest1 = "{$row1['sender']}";
		$idtest2 = "{$row1['receiver']}";
		if($idtest1 == $id){
			$idmain = $idtest2;
		}
		else{
			$idmain = $idtest1;
		}
		$query2 = "SELECT * FROM reguser WHERE id = '".$idmain."'";
		$res2 = mysql_query($query2);
		if(!$res2){
			echo "Couldn't handle query";
		}
		else{
			while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
				echo "<img src = '"."{$row2['profilepic']}'"." height = 100 width = 100 class = 'imgfriend' />";
				echo "<div class = 'namefriend'><a href = 'profile.php?id={$row2['id']}'>" . $row2['name']."</a><br>";
				echo "Class: {$row2['class']}<br>";
				echo "School: {$row2['school']}<br>";
				echo "Adm. No.: {$row2['admno']}<br></div>";
			}
		}
	}
	echo "<b><div style = 'margin-top:40px; margin-left: 120px;'>No more friends to show</b></div>";
}
?>
</div>
<div id = "suggestion">
<b><center><u><font color = "red" size = "8">Suggestions</font></u></center></b><br>
</div>
</body>
</html>