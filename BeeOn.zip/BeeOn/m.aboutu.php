<?php
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id = end($tmp);
	}
}
?>
<html>
<head>
<title>AboutU</title>
<meta style="color:red" name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60">
<link rel = "icon" type = "image/jpg" href = "logo_beeon.jpg">
<link rel = "stylesheet" type = "text/css" href = "w3.css">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$(".like").click(function() {
		var post_id = $(this).attr('id');
		var liker = <?php echo $id; ?>;
		var dataString = 'liker='+ liker+'&post_id=' +post_id;
		$.ajax({
			type: "POST",
			url: "liker.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! This post deserves like. Your liking will be visible within a minute");
			}  
		});		
		return false;
	});
	$(".put").click(function() {
		var post_id = $(this).attr('id');
		var user_id = <?php echo $id; ?>;
		var classo = '#post_textbox2'+post_id;
		var comment = $(classo).val();
		var dataString = 'user_id='+ user_id+'&post_id=' +post_id+'&comment='+comment;
		$.ajax({
			type: "POST",
			url: "put.php",
			data: dataString,
			cache: true,
			success: function(html){
				alert("Thanks! Comment on this post with open arms.Your comment will be visible within a minute");
			}  
		});		
		return false;
	});
});
</script>
</head>
<body>
<?php
include("m.sideview.php");
ob_start();
if($_SESSION['beeloggedin'] != 1){
	header("location:index.php");
}
else{
	foreach($_SESSION as $key=>$status){
		if(ereg("_",$key)){
			$tmp = explode("_",$key);
			$id = end($tmp);
			include("conn.php");
			$query = "SELECT name,emailid,school,class,admno,gender,profilepic FROM reguser WHERE id = '".$id."'";
			$retval = mysql_query($query,$conn);
			if(!($retval)){
				echo "Couldn't get appropriate result";
			}
			while($row = mysql_fetch_array($retval, MYSQL_ASSOC)){
				echo "<div class = 'w3-card-24 w3-red' style='text-align:center;'>";
				echo "<img style = 'border-radius:50%;' border = '2' width = '100' height = '100' alt = 'sorry' src = '"."{$row['profilepic']}"."'></img><br>";
				echo "<b>Emailid:</b> {$row['emailid']}"." <br>";
				echo "<b>Name: </b>{$row['name']}<br>";
				echo "<b>School: </b>{$row['school']}<br>";
				echo "<b>Class: </b>{$row['class']}<br>";
				echo "<b>Adm. No.: </b>{$row['admno']}<br>";
				echo "<b>Gender: </b>{$row['gender']}<br></div>";
				$query = "SELECT * FROM status_update WHERE user_id = '".$id."' ORDER BY id DESC LIMIT 15";
				$res = mysql_query($query,$conn);
				if(!($res)){
					echo "Couldn't get appropriate result";
				}
				else{
					while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
						$post_id = "{$row['id']}";
						$query2 = "SELECT * FROM reguser WHERE id = '".$row['user_id']."'";
						$res2 = mysql_query($query2,$conn);
						if(!($res2)){
							echo "Couldn't get appropriate result";
						}
						while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
							$user_image = "{$row2['profilepic']}";
							$gender = "{$row2['gender']}";
							if($gender == "Male"){
								$txt = "his";
							}
							else{
								$txt = "her";
							}
							echo "<div class = 'status'><img src = '".$row2['profilepic']."'class = 'w3-circle' width = 50 height = 50/>";
						}
						echo "updated $txt status on {$row['event_time']}";
						echo "<br>{$row['status_post']}";
						$image = "{$row['image']}";
						if($image == NULL){
							echo "<div class = 'showlikes'>";
							$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
							$reslike = mysql_query($querylike);
							$numlikes = mysql_num_rows($reslike);
							$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
							$boolres = mysql_query($boolquery);
							$boolno = mysql_num_rows($boolres);
							if($boolno){
								echo "<br><img src = 'images.png' class = 'liked' />";
								echo "<font color = blue>".$numlikes." user liked this</font>";
								echo "</div>";
								include("m.comment.php");
								echo "</div>";
							}
							else{
								echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
								echo "<font color = blue>".$numlikes." user liked this</font>";
								echo "</div>";
								include("m.comment.php");
								echo "</div>";
							}
						}
						else{
							echo "<br><img hspace = '70' src = '".$image ."' style = 'height: 50%; width: 70%;'>";
							echo "<div class = 'showlikes'>";
							$querylike = "SELECT * FROM likes WHERE post_id = '".$post_id."'";
							$reslike = mysql_query($querylike);
							$numlikes = mysql_num_rows($reslike);
							$boolquery = "SELECT * FROM likes WHERE post_id = '".$post_id."' AND liker = '".$id."'";
							$boolres = mysql_query($boolquery);
							$boolno = mysql_num_rows($boolres);
							if($boolno){
								echo "<br><img src = 'images.png' class = 'liked' />";
								echo "<font color = blue>".$numlikes." user liked this</font>";
								echo "</div>";
								include("m.comment.php");
								echo "</div>";
							}
							else{
								echo "<br><img src = 'download.png' class = 'like' id = '".$post_id."' />";
								echo "<font color = blue>".$numlikes." user liked this</font>";
								echo "</div>";
								include("m.comment.php");
								echo "</div>";
							}
						}
					}
			
				}
			}
		
		}
		else{
			//will look at you
		}	
	}
}
?>
</body>
</html>