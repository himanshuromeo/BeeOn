<?php
$receiver = $_POST['receiver'];
$sender = $_POST['sender'];
include("conn.php");
$query = "UPDATE friends SET accept = '1' WHERE sender = '".$sender."' AND receiver = '".$receiver."'";
$res = mysql_query($query);
if(!($res)){
	echo "Couldn't handle query";
}
else{
	echo "Sent";
}
?>