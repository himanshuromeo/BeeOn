<?php
include("conn.php");
$sqlchk = "SELECT * FROM reguser WHERE emailid ='".$_POST['txtEmail']."'";
$reschk = mysql_query($sqlchk);
$boolchk = mysql_num_rows($reschk);
// Assigning patterns and other variables
$emailpat = "^[a-zA-Z0-9\.]+@[a-zA-Z]+\.[a-zA-Z\.]+$";
$admnopat = "^[0-9]*$";
$filename = $_FILES['profilePic']['name'];
$tmp = explode(".",$filename);
$exts = end($tmp);
$newfilename = $_POST['txtEmail'].".".$exts;
$target_path = "ProfilePics/";
$target_path = $target_path.$newfilename;
// Validation of entry begins by checking if there is any blank field left
if($_POST['txtName'] == ""){
	echo "<div id = texten><center><b>Please enter your name</b></center></div>";
	include("sign_up.php");
}
elseif($boolchk){
	echo "<div id = texten><center><b>This emailid is already taken</b></center></div>";
	include("sign_up.php");
}
elseif($_POST['txtEmail'] == ""){
	echo "<div id = texten><center><b>Please enter your emailid</b></center></div>";
	include("sign_up.php");
}
elseif($_POST['pass'] == ""){
	echo "<div id = texten><center><b>Please select a password</b></center></div>";
	include("sign_up.php");
}
elseif(!(isset($_POST['slctSchool']))){
	echo "<div id = texten><center><b>Please select your school.</b></center></div>";
	include("sign_up.php");
}
elseif(!(isset($_POST['slctClass']))){
	echo "<div id = texten><center><b>Please select your class.</b></center></div>";
	include("sign_up.php");
}
elseif($_POST['txtadmno'] == ""){
	echo "<div id = texten><center><b>Please enter your Admission No.</b></center></div>";
	include("sign_up.php");
}
elseif(!(isset($_POST['radGender']))){
	echo "<div id = texten><center><b>Please select your gender</b></center></div>";
	include("sign_up.php");
}
elseif($_FILES['profilePic']['name'] == ""){
	echo "<div id = texten><center><b>Please choose your profile picture</b></center></div>";
	include("sign_up.php");
}
//Pattern validation begins
elseif(!(ereg($emailpat,$_POST['txtEmail']))){
	echo "<div id = texten><center><b>Please enter your email in the format 'abc@xyz.com' </b></center></div>";
	include("sign_up.php");
}
elseif(!(ereg($admnopat,$_POST['txtadmno']))){
	echo "<div id = texten><center><b>Please enter your Admission No. in the format '123456' </b></center></div>";
	include("sign_up.php");
}
elseif(!(ereg("^(jpg|jpeg|bmp|png|JPG|JPEG)$",$exts))){
	echo "<div id = texten><center><b>The file extension is not proper.It must be '.jpg' or '.jpeg' or '.bmp' or '.png'.</b></center></div>";
	include("sign_up.php");
}
//Actual process starts
else{
	if(move_uploaded_file($_FILES['profilePic']['tmp_name'], $target_path))
	{
		$query = "INSERT INTO reguser(name,emailid,password,school,class,admno,gender,profilepic) VALUES('".htmlentities($_POST['txtName'])."','".htmlentities($_POST['txtEmail'])."','".htmlentities($_POST['pass'])."','".$_POST['slctSchool']."','".$_POST['slctClass']."','".htmlentities($_POST['txtadmno'])."','".$_POST['radGender']."','".$target_path."')";
		$result = mysql_query($query);
		if($result){
			echo "<div id = texten><center><b>Successfull</b></center></div>";
			include("sign_up.php");
		}
		else{
			echo "<div id = texten><center><b>Couldn't handle query.Please try later</b></center></div>";
		}
	}
	else
	{
		echo "<div id = texten><center><b>Please choose another pic or try again later</b></center></div>";
	} 	
}
?>