<html>
<head>
<title>My own CHAT program</title>
<?php
function destroy(){
	session_start();
	foreach($_SESSION as $name=>$stat){
		if(ereg("@",$name)){
			unset($_SESSION["$name"]);
		}
	}
}
?>
<link rel="stylesheet" type="text/css" href="cb_style.css">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#send").click(function() {
		var textcontent = $("#message").val();
		var id1 = $("#hidid1").val();
		var id2 = $("#hidid2").val();
		var dataString = 'message='+ textcontent+'&sender=' +id1+'&receiver='+id2;
		if(textcontent=='')
		{
			alert("Enter some text..");
			$("#message").focus();
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "send.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById('message').value='';
					document.getElementById.innerHTML = "Sent";
					$("#message").focus();
				}  
			});
		}
		return false;
	});
});
</script>
<link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body onunload = "<?php destroy(); ?>">
<?php
include("conn.php");
include("sideview.php");
$id1 = $_POST['hidid1'];
$id2 = $_POST['hidid2'];
session_start();
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
	}
}
if(isset($_POST['hidid1'])){
	$id1 = $_POST['hidid1'];
}
else{
	$id1 = end($tmp);
}
if(isset($_GET['id'])){
	$id2 = $_GET['id'];
}
else{
	$id2 = $_POST['hidid2'];
}
$_SESSION[$id1."@".$id2] = 1;
foreach($_SESSION As $name=>$stat){
	if(ereg("@",$name)){
		$tmp = explode("@",$name);
		$idu1 = $tmp[0];
		$idu2 = $tmp[1];
	}
}
$setque = "UPDATE chat SET seen = 1 WHERE id2 = '".$idu1."'";
$resque = mysql_query($setque);
$sqlinfo1 = "SELECT * FROM reguser WHERE id = '".$idu1."'";
$resinfo1 = mysql_query($sqlinfo1);
while($rowinfo1 = mysql_fetch_array($resinfo1,MYSQL_ASSOC)){
	echo "<b><label style = 'margin-left:300px;'><a href = 'profile.php?id=".$rowinfo1['id']."'>{$rowinfo1['name']} </a></label>";
}
$sqlinfo2 = "SELECT * FROM reguser WHERE id = '".$idu2."'";
$resinfo2 = mysql_query($sqlinfo2);
while($rowinfo2 = mysql_fetch_array($resinfo2,MYSQL_ASSOC)){
	echo "is chatting with <label><a href = 'profile.php?id=".$rowinfo2['id']."'> {$rowinfo2['name']} </a></label>.</b>";
}
?>
<div id="chatBox"><?php include("show.php"); ?></div>
	<form method = "post" id="messageForm">
		<input id = "hidid1" type = "text" value = "<?php echo $idu1; ?>" />
		<input id = "hidid2" type = "text" value = "<?php echo $idu2; ?> "/>
		<input id="message" type="text" />
		<input id="send" type="submit" class = "submit_button"value="Send" />
<div id="serverRes"></div></form>
<form enctype = "multipart/form-data" method = "post" action = "chatpic.php?serve=<?php echo $idu2;?>">
		<input type = "file" id = "sbmt3" name = "chatpic" style = "margin-left:300px;"/>
		<input type = "submit" id = "send" value = "Send File" style = "margin-left:388px;"/>
</form>
<script>
$(function(){
	getchat();
});
function getchat(){
	$('#chatBox').load('show.php');
	setTimeout("getchat()",2000);
}
</script>
</body>
</html>