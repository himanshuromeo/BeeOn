<?php
include("sideview.php");
session_start();
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$id = end($tmp);
	}
}
?>
<html>
<head>
<title>My own CHAT program</title>
<link rel="stylesheet" type="text/css" href="cb_style.css">
<script src = "jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(function() {
	$("#send").click(function() {
		var textcontent = $("#message").val();
		var id = <?php echo $id; ?>;
		var dataString = 'message='+ textcontent+'&sender=' +id;
		if(textcontent=='')
		{
			alert("Enter some text..");
			$("#message").focus();
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "sendgrp.php",
				data: dataString,
				cache: true,
				success: function(html){
					document.getElementById('message').value='';
					document.getElementById.innerHTML = "Sent";
					$("#message").focus();
				}  
			});
		}
		return false;
	});
});
</script>
<link rel = "stylesheet" type = "text/css" href = "style.css">
</head>

<div id="chatBox"><?php include("showgrp.php"); ?></div>
	<form method = "post" id="messageForm">
		<input id="message" type="text" />
		<input id="send" type="submit" class = "submit_button"value="Send" />
<div id="serverRes"></div></form>
<script>
$(function(){
	getchat();
});
function getchat(){
	$('#chatBox').load('showgrp.php');
	setTimeout("getchat()",2000);
}
</script>
</body>
</html>