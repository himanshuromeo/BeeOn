<?php
session_start();
if(!($_SESSION['beeloggedin'] == 1)){
	header("location:index.php");
}
foreach($_SESSION as $key=>$stat){
	if(ereg("_",$key)){
		$tmp = explode("_",$key);
		$sess = end($tmp);
	}
}
include("m.sideview.php");
include("conn.php");
?>
<html>
<head>
<title>Chat</title>
<link rel = 'icon' type = 'image/jpg' href = 'logo_beeon.jpg'>
<link rel = 'stylesheet' type = 'text/css' href = 'w3.css'>
</head>
<body>
<div class = "w3-box">
<?php
$query2 = "SELECT * FROM reguser WHERE (id = '".$sess."')";
$res2 = mysql_query($query2);
if(!$res2){
	echo "Couldn't load";
}
else{
	while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
		echo "<div style = 'margin-left: 10%; margin-right: 10%;' class = 'w3-card-24 w3-red w3-hover-pink'>";
		echo "<form id = 'signInForm' action = 'm.chato.php' method = 'post'>";
		echo "<input type = 'hidden' name = 'hidid2' value = '"."{$row2['id']}"."' />";
		echo "<input type = 'hidden' name = 'hidid1' value = '".$sess."' />";
		echo "<img vspace = '10' hspace = '10' src= {$row2['profilepic']} height = '100' width = '100' style = 'border-radius:50%' />";
		echo "<div class = 'namo' style = 'margin-left:3%;'>{$row2['name']} ( Me )</div>";
		echo "<input class = 'w3-btn w3-blue w3-hover-green' style = 'margin-left:3%;' id = 'send2' type = 'submit' value = 'chat'/>";
		echo "</form>";
		echo "</div>";
	}
}
$query1 = "SELECT * FROM friends WHERE (sender = '".$sess."' OR receiver ='".$sess."') AND (accept = '1')";
$res1 = mysql_query($query1,$conn);
if(!($res1)){
	echo "Couldn't retrieve users name";
}
else{
	while($row1 = mysql_fetch_array($res1,MYSQL_ASSOC)){
		$query2 = "SELECT * FROM reguser WHERE (id != '".$sess."') AND (id = '".$row1['receiver']."' OR id = '".$row1['sender']."')";
		$res2 = mysql_query($query2);
		if(!$res2){
			echo "Couldn't load";
		}
		else{
			while($row2 = mysql_fetch_array($res2,MYSQL_ASSOC)){
				$seenque = "SELECT * FROM chat WHERE id1 = '".$row2['id']."' AND id2 = '".$sess."' AND seen = 0";
				$resque = mysql_query($seenque);
				$notseen = mysql_num_rows($resque);
				echo "<div class = 'w3-card-24 w3-red w3-hover-pink' style = 'margin-left: 10%; margin-right: 10%;'>";
				echo "<form id = 'signInForm' action = 'm.chato.php' method = 'post'>";
				echo "<input type = 'hidden' name = 'hidid2' value = '"."{$row2['id']}"."' />";
				echo "<input type = 'hidden' name = 'hidid1' value = '".$sess."' />";
				echo "<img vspace = '10' hspace = '10' src= {$row2['profilepic']} height = '100' width = '100' style = 'border-radius:50%' />";
				echo "<div class = 'namo' style = 'margin-left:3%;'>{$row2['name']} <div class = 'w3-badge w3-green'>$notseen</div></div>";
				echo "<input class = 'w3-btn w3-blue w3-hover-green' style = 'margin-left:3%;' id = 'send2' type = 'submit' value = 'chat'/>";
				echo "</form>";
				echo "</div>";
			}
		}
	}
}
?>
</div>
</body>
</html>