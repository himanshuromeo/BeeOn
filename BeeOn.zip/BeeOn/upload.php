<?php
include("conn.php");
$user_id = $_POST['user_id'];
$status_post = $_POST['status'];
$event_time = date('m/d/Y h:i:s a', time());
$filename = $_FILES['file1']['name'];
$tmp = explode(".",$filename);
$exts = end($tmp);
$target_path = "uploads/$filename";
echo "$user_id<br>".htmlentities($status_post)."<br>$target_path<br>$event_time";
if(!($filename == ""&& $status_post == "")){
	if(!(eregi("^(jpg|jpeg|bmp|png)$",$exts))){
		if($status_post == ""){
			echo "File must be of jpg, bmp or png extension";
		}
		else{
			$query = "INSERT INTO status_update(user_id,status_post,event_time) VALUES('".$user_id."','".mysql_escape_string($status_post)."','".$event_time."')";
			$res = mysql_query($query,$conn);
			if(!$res){
				echo "Couldn't upload your status1";
			}
			else{
				echo "Status updated successfully";
				header("location:main.php");
			}
		}
	}
	else{
		move_uploaded_file($_FILES['file1']['tmp_name'], $target_path);
		$query = "INSERT INTO status_update(user_id,status_post,image,event_time) VALUES('".$user_id."','".mysql_escape_string($status_post)."','".$target_path."','".$event_time."')";
		$res = mysql_query($query,$conn);
		if(!$res){
			echo "Couldn't upload your status2";
		}
		else{
			echo "Status updated successfully";
			header("location:main.php");
		}
	}
}
else{
	echo "Don't leave both the field empty";
}
?>