<?php
session_start();
if(eregi("Android",$_SERVER['HTTP_USER_AGENT'])){
	header("location:m.index.php");
}
elseif($_SESSION['beeloggedin'] == 1){
	header("location:main.php");
}
//This is gonna be processed since you set the login value to on
elseif($_GET['login']){
	if(!($_POST['txtid'] == ""||$_POST['txtpass'] == "")){
		$emailid = $_POST['txtid'];
		include("conn.php");
		$query = "SELECT id,emailid,password FROM reguser WHERE emailid = '".htmlentities($_POST['txtid'])."'AND password = '".htmlentities($_POST['txtpass'])."' ";
		$resultlogin = mysql_query($query);
		while($row = mysql_fetch_array($resultlogin, MYSQL_ASSOC)){
			$id = "{$row['id']}";
		}
		$num = mysql_num_rows($resultlogin);
		if($num){
			$_SESSION['beeloggedin'] = 1;
			$idf = "_"."$id";
			$_SESSION["$idf"] = 1; //A session by your name, now you will explore the world of h!m@nshU
			$oncheck = "SELECT * FROM online WHERE user_id='".$id."'";
			$resoncheck = mysql_query($oncheck);
			$numoncheck = mysql_num_rows($resoncheck);
			if($numoncheck){
				header("location:main.php"); 
			}
			else{
				$online = "INSERT INTO online(user_id) VALUES('".$id."')";
				$resonline = mysql_query($online);
				header("location:main.php");
			}
		}
		//Why did you get it wrong ??
		else{
			header("location:fail.php");
		}
	}
	else echo "<div id = texten><center><b>You did not enter something or the other.</b></center><hr color = red></div>";
}
?>
<html>
<head>
<title>Beeon</title>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<link rel="icon" type="image/jpg" href="logo_beeon.jpg">
</head>
<body style = "background: url(home.jpg);">
<div id = "mid">
<form method = "post" action = "?login=1"><b><font size = "5%">Log In:</font></b><br>
Email Id:<input type = "text" id = "txt" value = "" name = "txtid" />
Password: <input type = "password" id = "txt" value = "" name = "txtpass" />
<input type = "submit" id = "sbmt" value = "Login" />
</form>
<br>
<ul><li><a href = "sign_up.php">Sign Up</a></li></ul>
</div>
<div id = "end">
<font color = "black"><center><b>Developed by</b> Himanshu & Co.</center></font>
</div>
</body>
</html>