<?php
session_start();
foreach($_SESSION as $key=>$status){
		if(ereg("_",$key)){
			$tmp = explode("_",$key);
			$id = end($tmp);
			include("conn.php");
			$query = "SELECT name,emailid,school,class,admno,gender,profilepic FROM reguser WHERE id = '".$id."'";
			$retval = mysql_query($query,$conn);
			if(!($retval)){
				echo "Couldn't get appropriate result";
			}
			while($row = mysql_fetch_array($retval, MYSQL_ASSOC)){
				$img_link = "{$row['profilepic']}";
				$name = "{$row['name']}";
				$class = "{$row['class']}";
			}
			$seenque = "SELECT * FROM chat WHERE id2 = '".$id."' AND seen = 0";
			$resque = mysql_query($seenque);
			$notseen = mysql_num_rows($resque);
		}
	}
?>
<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
<div class = 'sidebar'>
<img src = "logo_beeon.jpg" height = "50" width = "100" hspace = "35" style = "border-radius: 50%; margin-top:-10%; margin-left:30%;" /><br>
<!--1---><div class = "side_link">
<a href = "main.php">
<table border = 0>
<tr>
<td><img src = "home.png" height = "50" width = "50" hspace = "8" /></td>
<td><font color = "white" size = "4">Home</td>
</tr>
</table>
</a>
</div>
<!---2---><div class = "side_link">
<a href = "aboutu.php">
<table border = 0>
<tr>
<td><img src = "<?php echo $img_link; ?>" height = "50" width = "50" hspace = "8" class = "user_dp"/></td>
<td><font color = "white" size = "4"><?php echo $name; ?></td>
</tr>
</table>
</a>
</div>
<!---3---><div class = "side_link">
<a href = "friends_list.php">
<table border = 0>
<tr>
<td><img src = "friends-icon.png" height = "50" width = "50" hspace = "8" /></td>
<td><font color = "white" size = "4">Friends</td>
</tr>
</table>
</a>
</div>
<!---4---><div class = "side_link">
<a href = "chat.php">
<table border = 0>
<tr>
<td><img src = "chat.png" height = "50" width = "50" hspace = "8" /></td>
<td><font color = "white" size = "4">Chat (<?php echo $notseen; ?>)</td>
</tr>
</table>
</a>
</div>
<!---5---><div class = "side_link">
<a href = "chat_common.php">
<table border = 0>
<tr>
<td><img src = "received.png" height = "50" width = "50" hspace = "8" /></td>
<td><font color = "white" size = "4">Common Chat</td>
</tr>
</table>
</a>
</div>
<!---6---><div class = "side_link">
<a href = "notes.php?sub=maths&class=<?php echo $class; ?>">
<table border = 0>
<tr>
<td><img src = "notes.png" height = "50" width = "50" hspace = "8" /></td>
<td><font color = "white" size = "4">Share Notes</td>
</tr>
</table>
</a>
</div>
<!---6---><div class = "side_link">
<a href = "settings.php">
<table border = 0>
<tr>
<td><img src = "settings.png" height = "50" width = "50" hspace = "8" style = "border-radius: 50%;"/></td>
<td><font color = "white" size = "4">Settings</td>
</tr>
</table>
</a>
</div>
<!---7---><div class = "side_link">
<a href = "logout.php">
<table border = 0>
<tr>
<td><img src = "logout.png" height = "50" width = "50" hspace = "8" style = "border-radius: 50%;"/></td>
<td><font color = "white" size = "4">Log Out</td>
</tr>
</table>
</a>
</div>
</div>
<div class="online" style="display:none;">
	<a href="javascript:void(0)" onclick="w3_close2()"><font color="white" size="6">Close &times;</font></a><br>
	<?php
	$query1 = "SELECT * FROM online";
	$res1 = mysql_query($query1);
	while($row1=mysql_fetch_array($res1,MYSQL_ASSOC)){
		$query2 = "SELECT * FROM friends WHERE (sender = '".$id."' AND receiver = '".$row1['user_id']."' AND accept = '1') OR (sender = '".$row1['user_id']."' AND receiver = '".$id."' AND accept = '1')";
		$res2 = mysql_query($query2);
		$bool2 = mysql_num_rows($res2);
		if($bool2){
			$query3 = "SELECT * FROM reguser WHERE id = '".$row1['user_id']."'";
			$res3 = mysql_query($query3);
			while($row3 = mysql_fetch_array($res3,MYSQL_ASSOC)){
				echo "<a href = chato.php?id={$row1['user_id']} ";
				echo "<table border = 0>";
				echo "<tr>";
				echo "<td><img src = {$row3['profilepic']} height = 50 width = 50 hspace = 8 style='border-radius:50%;'/></td>";
				echo "<td><font color = white size = 4>{$row3['name']}</font></td>";
				echo "</tr>";
				echo "</table>";
				echo "</a><br>";
			}
		}
		else{
			//let's see
		}
	}
	?>
</div>
<span class="invoker" style = "margin-left:95%;float:right;position:fixed;border-style:solid;border-color:green;border-width:2px;" onclick="w3_open2()"><img src = 'on.png' /></span> 
<script>
function w3_open2() {
    document.getElementsByClassName("online")[0].style.display = "block";
}
function w3_close2() {
    document.getElementsByClassName("online")[0].style.display = "none";
}
</script>
</body>
</html>